<?php
class GDTreinamentoDAO{
    public function getTreinamentos($con,$userData){
        try{            
            $sql = "SELECT 
                        B.codcua AS [id_treinamento],B.nomred AS [nm_treinamento],
                        B.nomcua AS [nick_treinamento],A.tmacua AS [id_turma],
                        A.datini AS [dt_inicio], A.datfim AS [dt_fim],
                        A.carhor AS [carga_horaria], A.qtdvag AS [lotacao],
                        A.medcua AS [minimo], A.frecua AS [frequencia],
                        A.descon AS [conteudo_program], A.desobu AS [desc],D.deshor AS [horario],
                        E.tipins AS [tipo_instrutor], E.obsins AS [obs_instrutor],
                        F.numcad AS [numcad_instrutor], F.nomfun AS [nome_instrutor],
                        SLA.dessla AS [nome_sala], SLA.nompre AS [local_sala]
                        FROM VETORH.R134DTU A
                        INNER JOIN VETORH.R128CUA B
                            ON A.codcua = B.codcua
                        INNER JOIN VETORH.R134HOR C
                            ON A.tmacua = C.tmacua AND B.codcua = C.codcua
                        INNER JOIN VETORH.R133HCU D
                            ON D.codhcu = C.codhcu
                        INNER JOIN VETORH.r134ins E
                            ON A.codcua = E.codcua AND A.tmacua = E.tmacua
                        INNER JOIN VETORH.r034fun F
                            ON E.numcad = F.numcad
                        INNER JOIN VETORH.R140SLA SLA
                            ON C.codsla = SLA.codsla
                        WHERE B.conweb = 'S'
                        and year(A.datini) BETWEEN :bYear AND :aYear
                        ORDER BY A.datini DESC, A.datfim DESC";
            $statement = $con->prepare($sql);
            $statement->bindValue(":bYear",$userData->bYear);
            $statement->bindValue(":aYear",$userData->aYear);
            $result = $con->executeQuery($statement);        
            return $result;            
        }catch(Exception $e){
            throw array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
    public function insertCandidato($con,$dados){
        try{            
            $sqlR134DRE = "INSERT INTO VETORH.R134DRE 
                    (codcua,tmacua,numemp,tipcol,numcad,conemi,ceremi,freemi,taborg,numloc,datins,datter,lnkead,codccu,datcon)
                VALUES
                    (".$dados->codcua.",".$dados->tmacua.",".$dados->numemp.",1,".$dados->numcad.",'N','N','N',3,".$dados->numloc.",'".$dados->datins."','1900-12-31 00:00:00','',".$dados->codccu.",'1900-12-31 00:00:00')";
            $statementR134DRE = $con->prepare($sqlR134DRE);
            $resultR134DRE = $con->executeQuery($statementR134DRE);        
            $sqlR140NPC = "INSERT INTO VETORH.R140NPC 
                    (codcua,tmacua,numemp,tipcol,numcad,qtdfal,tipcer,numcer,sitcua,codmin,sitare,sitant,horfal)
                VALUES
                    (".$dados->codcua.",".$dados->tmacua.",".$dados->numemp.",1,".$dados->numcad.",0,'A',0,1,0,1,0,0)";
            $statementR140NPC = $con->prepare($sqlR140NPC);
            $resultR140NPC = $con->executeQuery($statementR140NPC);        
            return array($resultR134DRE,$resultR140NPC);            
        }catch(Exception $e){
            throw array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
    public function getInscritosPorTreinamentos($con,$dados,$numcad = null){
        try{       
            $condicionais = $numcad!=null?" AND A.numcad=$numcad":" AND DES.sitcua NOT IN (3,4,8,9,10)";            
            $sql = "SELECT DISTINCT A.codcua,A.tmacua,A.numloc,A.numcad,L.nomloc,B.nomfun 
                        FROM VETORH.R134DRE A
                        INNER JOIN VETORH.R034FUN B
                        ON A.numcad = B.numcad
                        INNER JOIN VETORH.R016ORN L
                        ON A.numloc = L.numloc
                        INNER JOIN VETORH.R140NPC DES
                        ON (A.numcad = DES.numcad AND A.codcua = DES.codcua AND A.tmacua = DES.tmacua)
                        WHERE A.codcua=:codcua
                        AND A.tmacua=:tmacua".
                        $condicionais;
            $statement = $con->prepare($sql);
            $statement->bindValue(":codcua",$dados->codcua);
            $statement->bindValue(":tmacua",$dados->tmacua);
            $result = $con->executeQuery($statement);
            return $result;            
        }catch(Exception $e){
            throw array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
    public function cancelaInscricao($con,$dados){
        try{                  
            $sql = "UPDATE VETORH.R140NPC
                        SET sitcua=3
                    WHERE codcua=:codcua
                        AND tmacua=:tmacua
                        AND numcad=:numcad";
            $statement = $con->prepare($sql);
            $statement->bindValue(":codcua",$dados->codcua);
            $statement->bindValue(":tmacua",$dados->tmacua);
            $statement->bindValue(":numcad",$dados->numcad);
            $result = $con->executeQuery($statement);        
            return $result;            
        }catch(Exception $e){
            throw array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }

    public function getInscricoesTreinamentoByColab($con,$dados){
        try{       
            $sql = "SELECT DISTINCT A.codcua,A.tmacua,A.numloc,A.numcad,L.nomloc,B.nomfun,T.datfim
                        FROM VETORH.R134DRE A
                    INNER JOIN VETORH.R034FUN B
                        ON (A.numcad = B.numcad)
                    INNER JOIN VETORH.R016ORN L
                        ON (A.numloc = L.numloc)
                    INNER JOIN VETORH.R134DTU T
                        ON (A.codcua = T.codcua AND A.tmacua = T.tmacua)
                    INNER JOIN VETORH.R140NPC DES
                        ON (A.numcad = DES.numcad AND A.codcua = DES.codcua AND A.tmacua = DES.tmacua)
                    WHERE B.numcad = :numcad
                    AND DES.sitcua NOT IN (3,4,8,9,10)
                    AND year(T.datfim) BETWEEN :bYear AND :aYear";
            // "SELECT DISTINCT A.codcua,A.tmacua,A.numloc,A.numcad,L.nomloc,B.nomfun,A.datins 
            //             FROM VETORH.R134DRE A
            //         INNER JOIN VETORH.R034FUN B
            //             ON A.numcad = B.numcad
            //         INNER JOIN VETORH.R016ORN L
            //             ON A.numloc = L.numloc
            //         WHERE B.numcad = :numcad
            //         AND year(A.datins) BETWEEN :bYear AND :aYear";
                    
            $statement = $con->prepare($sql);
            $statement->bindValue(":numcad",$dados->numcad);
            $statement->bindValue(":bYear",$dados->bYear);
            $statement->bindValue(":aYear",$dados->aYear);
            $result = $con->executeQuery($statement);        
            return $result;            
        }catch(Exception $e){
            throw array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
	public function getVagasTreinamento($con,$dados){
        try{                  
            // $sql = "SELECT (qtdvag - (
            //                 SELECT COUNT(*) FROM VETORH.R140NPC 
            //                 WHERE codcua=:codcua AND tmacua=:tmacua AND sitcua NOT IN (3,4,8,9,10)
            //             )
            //         ) AS [vagas] FROM VETORH.R134DTU
            //         WHERE codcua=:codcua
            //         AND tmacua=:tmacua";
            $sql = "SELECT (qtdvag - (
                            SELECT COUNT(*) FROM VETORH.R140NPC 
                            WHERE codcua=".$dados->codcua." AND tmacua=".$dados->tmacua." AND sitcua NOT IN (3,4,8,9,10)
                        )
                    ) AS [vagas] FROM VETORH.R134DTU
                    WHERE codcua=".$dados->codcua."
                    AND tmacua=".$dados->tmacua;
            $statement = $con->prepare($sql);
            // $statement->bindValue(":codcua",$dados->codcua);
            // $statement->bindValue(":tmacua",$dados->tmacua);
            $result = $con->executeQuery($statement);        
            return $result;            
        }catch(Exception $e){
            throw array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }







}
?>