<?php
include_once 'GDTreinamentoDAO.php';
include_once 'TbTreinamentoCandidaturaDAO.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/treinamentos/services/v1/helpers/StringFormat.php';
include_once $_SERVER['DOCUMENT_ROOT'].'/treinamentos/services/v1/helpers/StringFormat.php';

class GDTreinamentoBO{
    public function controller($action,$conexoes,$userData){
        switch($action){
            case 'listaTreinamentos':
                return $this->listaTreinamentos($conexoes,$userData);
            break;            
            case 'insereCandidato':
                return $this->insereCandidato($conexoes,$userData);
            break;                 
            case 'cancelaCandidato':
                return $this->cancelaCandidato($conexoes,$userData);
            break;                 
            case 'consultaCandidatoTreinamento':
                return $this->consultaCandidatoTreinamento($conexoes,$userData);
            break;                 
            case 'limpTreinCanc':
                return $this->limpTreinCanc($conexoes,$userData);
            break;                 
            default:
            return array("msg"=>"Por favor selecione a ação correta vetorh!");
        }
    }
    public function getYears(){
        return array((date('Y')-1),(date('Y')+1));
    }
    public function listaTreinamentos($conexoes,$userData){
        try{
            $year = $this->getYears();
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $tbTreinamentoCandidaturaDAO = new TbTreinamentoCandidaturaDAO();
            $dataTreinamentos = json_decode(json_encode(array("bYear"=>$year[0],"aYear"=>$year[1])),FALSE);
            $treinamentos = $gdTreinamentoDAO->getTreinamentos($conexoes['vetorhCon'],$dataTreinamentos);
            $incritosObrigatorios = $this->getIncricoesObrigatorios($conexoes,$userData,$year);
            $listaTreinamentos = array(
                "dataTreinamentos"=>$this->listaDataTreinamento($treinamentos),
                "treinamentos"=>$treinamentos,
                "calendario"=>$this->listaDataNome($treinamentos,$incritosObrigatorios),
                "treinamentosColab"=>$this->getColabInscritos($conexoes['vetorhCon'],$treinamentos),
                "userData"=>$userData,
                "incritosObrigatorios"=>$incritosObrigatorios
            );

            return $listaTreinamentos;
        }catch(Exception $e){
            throw array(
                    "error"=>"Por favor selecione uma ação!",
                    "exception"=>$e->getMessage()
                );
        }
    }
    public function getIncricoesObrigatorios($conexoes,$dados,$year){
        try{
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $tbTreinamentoCandidaturaDAO = new TbTreinamentoCandidaturaDAO();
            $inscricoes = $tbTreinamentoCandidaturaDAO->getCandidaturaUsuario(
                $conexoes['treinamentosCon'],
                json_decode(json_encode(array(
                    "bYear"=>$year[0],"aYear"=>$year[1],"fk_usuario"=> $dados->param->usuario->user->id
                )),FALSE));
            $obrigatorios = $gdTreinamentoDAO->getInscricoesTreinamentoByColab(
                $conexoes['vetorhCon'],
                json_decode(json_encode(array(
                    "bYear"=>$year[0],"aYear"=>$year[1],"numcad"=> $dados->param->usuario->user->matricula
                )),FALSE));                
            $colorTags = [];
            $today = strtotime(date('Y-m-d'));            
            for($i=0;$i<count($obrigatorios);$i++){
                $dtFimTreinamento = strtotime($obrigatorios[$i]['datfim']);
                $treinamentoTag = array("fk_treinamento"=>$obrigatorios[$i]["codcua"],
                    "fk_turma"=>$obrigatorios[$i]["tmacua"],"tag"=>"red-tag"
                );
                for($x=0;$x<count($inscricoes);$x++){
                    $fkTreinamento = $inscricoes[$x]["fk_treinamento"]==$obrigatorios[$i]["codcua"];
                    $fkTurma = $inscricoes[$x]["fk_turma"]==$obrigatorios[$i]["tmacua"];
                    if($fkTreinamento && $fkTurma){
                        $treinamentoTag["tag"]="purple-tag";
                    }
                }                
                if($today>$dtFimTreinamento){
                    $treinamentoTag["tag"]="green-tag";
                }
                array_push($colorTags,$treinamentoTag);
            }
            return $colorTags;
        }catch(Exception $e){
            throw array(
                    "error"=>"Problemas na busca da inscrição",
                    "exception"=>$e->getMessage()
                );
        }
    }
    public function insereCandidato($conexoes,$dados){
        try{
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $tbTreinamentoCandidaturaDAO = new TbTreinamentoCandidaturaDAO();
            $treinamento = $dados->param->treinamento;
            $usuario = $dados->param->usuario;
            $candidaturaData = array(
                "codcua"=>$treinamento->id_treinamento,
                "tmacua"=>$treinamento->id_turma,
                "numemp"=>$usuario->userRH->id_emp,
                "numcad"=>$usuario->userRH->matricula,
                "datins"=>$treinamento->data." 00:00:00",
                "codccu"=>$usuario->userRH->codccu,
                "numloc"=>$usuario->userRH->numloc
            );
            $candidatura = json_decode(json_encode($candidaturaData),FALSE);
            $vagas = $gdTreinamentoDAO->getVagasTreinamento($conexoes['vetorhCon'],$candidatura);
            if(($vagas[0]['vagas']*1)>0){
                $insertCandidatura = $gdTreinamentoDAO->insertCandidato($conexoes['vetorhCon'],$candidatura);
                $candidaturaTreinamento = json_decode(json_encode(
                    array(
                        "fk_usuario"=>$usuario->user->id,
                        "fk_treinamento"=>$treinamento->id_treinamento,
                        "fk_turma"=>$treinamento->id_turma
                    )
                ),FALSE);
                $tbTreinamentoCandidaturaDAO->save($conexoes['treinamentosCon'],$candidaturaTreinamento);
            }

            return array(
                "candidatura"=>($vagas[0]['vagas']*1)>0?true:false
            );
        }catch(Exception $e){
            throw array(
                    "error"=>"Por favor selecione uma ação!",
                    "exception"=>$e->getMessage()
                );
        }
    }
    public function cancelaCandidato($conexoes,$dados){
        try{
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $tbTreinamentoCandidaturaDAO = new TbTreinamentoCandidaturaDAO();
            $candidaturaData = array(
                "codcua"=>$dados->param->treinamento->id_treinamento,
                "tmacua"=>$dados->param->treinamento->id_turma,
                "numcad"=>$dados->param->usuario->userRH->matricula,
                "fk_treinamento"=>$dados->param->treinamento->id_treinamento,
                "fk_turma"=>$dados->param->treinamento->id_turma,
                "fk_usuario"=>$dados->param->usuario->user->id
            );
            $candidatura = json_decode(json_encode($candidaturaData),FALSE);
            $cancelaCandidatura = $gdTreinamentoDAO->cancelaInscricao($conexoes['vetorhCon'],$candidatura);
            $candidaturaExclu = $tbTreinamentoCandidaturaDAO->deleteCandidaturaUsuario($conexoes['treinamentosCon'],$candidatura);
            return array(
                "cancelamento"=>count($cancelaCandidatura)==0?true:false,
                "exclusaoCandidatura"=>$candidaturaExclu
            );
        }catch(Exception $e){
            throw array(
                    "error"=>"Por favor selecione uma ação!",
                    "exception"=>$e->getMessage()
                );
        }
    }
    
    public function consultaCandidatoTreinamento($con,$dados){
        try{
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $treinamento = $dados->param->treinamento;
            $usuario = $dados->param->usuario;
            $candidatura = json_decode(json_encode(array(
                "codcua"=>$treinamento->id_treinamento,"tmacua"=>$treinamento->id_turma
            )),FALSE);            
            return array(
                "candidatura"=>$gdTreinamentoDAO->getInscritosPorTreinamentos($con['vetorhCon'],$candidatura,$usuario->matricula)
            );
        }catch(Exception $e){
            throw array(
                    "error"=>"Por favor selecione uma ação!",
                    "exception"=>$e->getMessage()
                );
        }
    }
    public function getColabInscritos($con,$listaTreinamentos){
        try{
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $listaColabs = array();
            for($i=0;$i<count($listaTreinamentos);$i++){
                $consultaColab = json_decode(json_encode(array("codcua"=>$listaTreinamentos[$i]['id_treinamento'],"tmacua"=>$listaTreinamentos[$i]['id_turma'])),FALSE);                
                $listaColabs[$consultaColab->codcua][$consultaColab->tmacua] = $gdTreinamentoDAO->getInscritosPorTreinamentos($con,$consultaColab);
            }            
            return $listaColabs;
        }catch(Exception $e){
            throw array(
                    "error"=>"Por favor selecione uma ação!",
                    "exception"=>$e->getMessage()
                );
        }
    }

    public function listaDataNome($listaTreinamentos,$treinamentoTag){
        try{

            $dataNome = array();
            for($i=0;$i<count($listaTreinamentos);$i++){
                $formatedData = explode(' ',$listaTreinamentos[$i]['dt_inicio']);
                $arrayInfo = array($listaTreinamentos[$i]['nick_treinamento'],
                        $listaTreinamentos[$i]['dt_fim'],
                        $listaTreinamentos[$i]['id_treinamento'],
                        $listaTreinamentos[$i]['id_turma']);
                if(isset($dataNome[$formatedData[0]])){
                    array_push($dataNome[$formatedData[0]],$arrayInfo);
                }else{
                    $dataNome[$formatedData[0]] = array($arrayInfo);
                }
            }
            foreach($dataNome as $key => $data){
                $htmlTags = '';
                for($x=0;$x<count($data);$x++){
                    $id = $data[$x][2].$data[$x][3];
                    $getTagColors = null;
                    for($y=0;$y<count($treinamentoTag);$y++){
                        if($treinamentoTag[$y]['fk_treinamento']==$data[$x][2] && $treinamentoTag[$y]['fk_turma']==$data[$x][3]){
                           $getTagColors =  $treinamentoTag[$y]['tag'];
                        }
                    }
                    if($getTagColors==null){
                        $getTagColors = $this->getTagColors($data[$x][1]);
                    }
                    $obs = $getTagColors=='red-tag'?'(Treinamento obrigatório)':'';
                    $htmlTags.="<p id='tag".$id."' class='eventTag ".$getTagColors."' title='".$data[$x][0]." ".$obs."'>".$data[$x][0]."</p>";
                    // $htmlTags.="<p class='eventTag ".$this->getTagColors($data[$x][1])."' title='".$data[$x][0]."'>".$data[$x][0]."</p>";
                }
                $dataNome[$key] = "<div layout='row' layout-wrap layout-align='center center'>".$htmlTags."</div>";
            }
            return $dataNome;
        }catch(Exception $e){
            throw array(
                    "error"=>"Problemas ao listar treinamentos",
                    "exception"=>$e->getMessage()
                );
        }
    }
    public function listaDataTreinamento($listaTreinamentos){
        try{
            $dataNome = array();
            for($i=0;$i<count($listaTreinamentos);$i++){
                $formatedDataInicio = explode(' ',$listaTreinamentos[$i]['dt_inicio']);
                $formatedDataFim = explode(' ',$listaTreinamentos[$i]['dt_fim']);
                $treinamentoObj = array(
                        "nome"=> $listaTreinamentos[$i]['nm_treinamento'],
                        "id_treinamento"=> $listaTreinamentos[$i]['id_treinamento'],
                        "id_turma"=> $listaTreinamentos[$i]['id_turma'],
                        // "id"=> $listaTreinamentos[$i]['id_treinamento'],
                        "lotacao"=>$listaTreinamentos[$i]['lotacao'],
                        "pontuacao"=>"0",
                        "desc"=> $listaTreinamentos[$i]['desc'],
                        "horario"=> StringFormat::seniorFormatHorarios($listaTreinamentos[$i]['horario']),
                        "conteudoProgramatico"=> preg_split("/\\r\\n|\\r|\\n/", $listaTreinamentos[$i]['conteudo_program']),
                        "data"=>$formatedDataInicio[0],
                        "termina"=>$formatedDataFim[0],
                        "cargaHoraria"=> $listaTreinamentos[$i]['carga_horaria'],
                        "nome_sala"=> $listaTreinamentos[$i]['nome_sala'],
                        "local_sala"=> $listaTreinamentos[$i]['local_sala'],
                        "instrutor"=> [
                            "id"=>$listaTreinamentos[$i]['numcad_instrutor'],
                            "nome"=> $listaTreinamentos[$i]['nome_instrutor'],
                            "desc"=> $listaTreinamentos[$i]['obs_instrutor']
                        ],
                        "colaboradores"=>[
                            
                        ]
                    );
                if(isset($dataNome[$formatedDataInicio[0]])){
                    array_push($dataNome[$formatedDataInicio[0]],$treinamentoObj);
                }else{
                    $dataNome[$formatedDataInicio[0]]=array($treinamentoObj);
                }
            }
            return $dataNome;
        }catch(Exception $e){
            throw array(
                    "error"=>"Problemas ao listar treinamentos",
                    "exception"=>$e->getMessage()
                );
        }
    }
    public function getTagColors($dtFim){
        try{    
            $color = 'blue-tag';
            $formatedData = explode(' ',$dtFim);
            $dtFimTraina = strtotime($formatedData[0]);
            $today = strtotime(date('Y-m-d'));
            if($today>$dtFimTraina){
                $color = 'grey-tag';
            }
            return $color;
        }catch(Exception $e){
            throw array(
                    "error"=>"Problemas ao listar treinamentos",
                    "exception"=>$e->getMessage()
                );
        }
    }

    public function limpTreinCanc($conexoes,$data){
        try{        
            $year = $this->getYears();
            $usuario = $data->param->usuario;    
            $gdTreinamentoDAO = new GDTreinamentoDAO();
            $tbTreinamentoCandidaturaDAO = new TbTreinamentoCandidaturaDAO();
            $candData = json_decode(json_encode(array("bYear"=>$year[0],"aYear"=>$year[1],"fk_usuario"=> $usuario->user->id)),FALSE);
            $candidaturas = $tbTreinamentoCandidaturaDAO->getCandidaturaUsuario($conexoes['treinamentosCon'],$candData);
            for($i=0;$i<count($candidaturas);$i++){
                $findTreinaSenior = json_decode(json_encode(array("codcua"=>$candidaturas[$i]['fk_treinamento'],"tmacua"=>$candidaturas[$i]['fk_turma'])),FALSE);
                $treinaSenior = $gdTreinamentoDAO->getInscritosPorTreinamentos($conexoes['vetorhCon'],$findTreinaSenior,$usuario->user->matricula);
                if(count($treinaSenior)<=0){
                    $candidaturaRemovida = json_decode(json_encode(array("fk_turma"=>$candidaturas[$i]['fk_turma'],"fk_treinamento"=>$candidaturas[$i]['fk_treinamento'],"fk_usuario"=> $usuario->user->id)),FALSE);
                    $tbTreinamentoCandidaturaDAO->deleteCandidaturaUsuario($conexoes['treinamentosCon'],$candidaturaRemovida);
                }
            }
            $listaTreinamentos = array(
                "dataTreinamentos"=>$usuario,
                "candidaturas"=>$candidaturas
            );

            return $listaTreinamentos;
        }catch(Exception $e){
            throw array(
                    "error"=>"Por favor selecione uma ação!",
                    "exception"=>$e->getMessage()
                );
        }
    }

}
?>