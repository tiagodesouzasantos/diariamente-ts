<?php
class GDFuncionarioDAO{
    public function findByCPF($con,$userData){
        try{
            $sql = "SELECT 
                    A.numcad AS [matricula], A.numcpf AS [cpf],
                    A.nomfun AS [nome], A.apefun AS [apelido], A.tipsex AS [sexo],
                    B.numemp AS [id_emp], B.apeemp AS [nm_fantasia_emp],
                    A.tipcol AS [tip_col],
                    A.codccu AS [codccu],
                    A.numloc AS [numloc],
                    C.emapar AS [email]
                FROM VETORH.R034FUN A
                INNER JOIN VETORH.R030EMP B
                ON (A.numemp = B.numemp)
                INNER JOIN VETORH.R034CPL C
                ON (A.numcad = C.numcad)
                WHERE A.numcpf = :numcpf
                AND A.sitafa NOT IN (2,3,4,6,7,11,14,24,53,54,56)
                ORDER BY A.datsal DESC";
             //AND A.sitafa=1
            $statement = $con->prepare($sql);
            $statement->bindValue(":numcpf",$userData->cpf);                    
            $result = $con->executeQuery($statement);        
            return $result;            
        }catch(\Exception $e){
            return array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
}
?>