<?php
class TbTreinamentoCandidaturaDAO{
    public function save($con,$data){
        try{
            $sql = "INSERT INTO TB_TREINAMENTO_CANDIDATURA (fk_usuario,fk_treinamento,fk_turma)
                        OUTPUT Inserted.id
                    VALUES (:fk_usuario,:fk_treinamento,:fk_turma);";
            $statement = $con->prepare($sql);
            $statement->bindValue(":fk_usuario",$data->fk_usuario);                    
            $statement->bindValue(":fk_treinamento",$data->fk_treinamento);                    
            $statement->bindValue(":fk_turma",$data->fk_turma);                    
            $result = $con->executeQuery($statement);        
            return $result;            
        }catch(\Exception $e){
            return array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
    public function getCandidaturaUsuario($con,$data){
        try{
            $sql = "SELECT * FROM TB_TREINAMENTO_CANDIDATURA
                        WHERE fk_usuario=:fk_usuario
                        AND year(data_cand) BETWEEN :bYear AND :aYear";
            $statement = $con->prepare($sql);
            $statement->bindValue(":fk_usuario",$data->fk_usuario);                    
            $statement->bindValue(":bYear",$data->bYear);                    
            $statement->bindValue(":aYear",$data->aYear);                    
            $result = $con->executeQuery($statement);        
            return $result;  
        }catch(\Exception $e){
            return array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }
    public function deleteCandidaturaUsuario($con,$data){
        try{
            $sql = "DELETE FROM TB_TREINAMENTO_CANDIDATURA
                        WHERE fk_usuario=:fk_usuario
                        AND fk_treinamento=:fk_treinamento
                        AND fk_turma=:fk_turma";
            $statement = $con->prepare($sql);
            $statement->bindValue(":fk_usuario",$data->fk_usuario);                    
            $statement->bindValue(":fk_treinamento",$data->fk_treinamento);                    
            $statement->bindValue(":fk_turma",$data->fk_turma);                    
            $result = $con->executeQuery($statement);        
            return $result;  
        }catch(\Exception $e){
            return array("erro"=>"Problemas na busca dos dados!","exception"=>$e->getMessage);
        }
    }

}
?>