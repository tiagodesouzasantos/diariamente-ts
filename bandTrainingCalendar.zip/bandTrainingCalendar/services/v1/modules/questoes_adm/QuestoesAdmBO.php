<?php
include_once 'TbAvaliacaoQuestoesDAO.php';
include_once 'TbAvaliacaoRespostasDAO.php';

class QuestoesAdmBO{
    public function controller($action,$conexoes,$dados){
        switch($action){
            case 'listaQuestoes':
                return $this->listaQuestoes($conexoes);
            break;                    
            case 'saveQuestoes':
                return $this->saveQuestoes($conexoes,$dados);
            break;                    
            case 'atualizaQuestoes':
                return $this->atualizaQuestoes($conexoes,$dados);
            break;                    
            case 'deleteQuestoes':
                return $this->deleteQuestoes($conexoes,$dados);
            break;                    
            case 'deleteResposta':
                return $this->deleteResposta($conexoes,$dados);
            break;                    
            default:
            return array();
        }
    }

    public function listaQuestoes($con){
        try{
            $tbAvaliacaoQuestoesDAO =  new TbAvaliacaoQuestoesDAO();
            $TbAvaliacaoRespostasDAO =  new TbAvaliacaoRespostasDAO();
            $questoes = $tbAvaliacaoQuestoesDAO->lista($con['treinamentosCon']);
            for($i=0;$i<count($questoes);$i++){
                $respostas = $TbAvaliacaoRespostasDAO->findByQuestao($con['treinamentosCon'],$questoes[$i]['id']);
                $questoes[$i]['respostas'] = $respostas;
            }
            return array(
                "questoes"=>$questoes
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter questões!","exception"=>$e->getMessage());
        }
    }

    public function saveQuestoes($con,$data){
        try{
            $novaQuestao = $data->param;
            $tbAvaliacaoQuestoesDAO =  new TbAvaliacaoQuestoesDAO();
            $TbAvaliacaoRespostasDAO =  new TbAvaliacaoRespostasDAO();
            $questaoSalva = $tbAvaliacaoQuestoesDAO->save($con['treinamentosCon'],$novaQuestao->questao);
            for ($i=0;$i<count($novaQuestao->respostas);$i++){
                $novaQuestao->respostas[$i]->correta = ($i==$novaQuestao->correta?1:0); 
                $novaQuestao->respostas[$i]->fk_avaliacao_questoes = $questaoSalva[0]['id'];
                $respostaSalva = $TbAvaliacaoRespostasDAO->save($con['treinamentosCon'],$novaQuestao->respostas[$i]);
            }
            
            return array(
                "questaoSalva"=>$questaoSalva,
                "respostaSalva"=>$respostaSalva,
                "novaQuestao"=>$novaQuestao
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter questões!","exception"=>$e->getMessage());
        }
    }
    public function atualizaQuestoes($con,$data){
        try{
            $novaQuestao = $data->param;
            $tbAvaliacaoQuestoesDAO =  new TbAvaliacaoQuestoesDAO();
            $TbAvaliacaoRespostasDAO =  new TbAvaliacaoRespostasDAO();
            $questaoAtualizada = $tbAvaliacaoQuestoesDAO->update($con['treinamentosCon'],$novaQuestao->questao);
            $respostaSalva = [];
            for ($i=0;$i<count($novaQuestao->respostas);$i++){
                $novaQuestao->respostas[$i]->correta = ($i==$novaQuestao->correta?1:0); 
                $novaQuestao->respostas[$i]->fk_avaliacao_questoes = $questaoAtualizada;
                if(isset($novaQuestao->respostas[$i]->id)){
                    $respostaSalva[$i] = $TbAvaliacaoRespostasDAO->update($con['treinamentosCon'],$novaQuestao->respostas[$i]);
                }else{
                    $respostaSalva[$i] = $TbAvaliacaoRespostasDAO->save($con['treinamentosCon'],$novaQuestao->respostas[$i]);
                }
            }
            
            return array(
                "questaoAtualizada"=>$questaoAtualizada,
                "respostaSalva"=>$respostaSalva,
                "novaQuestao"=>$novaQuestao
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter questões!","exception"=>$e->getMessage());
        }
    }
    public function deleteQuestoes($con,$data){
        try{
            $novaQuestao = $data->param;
            $tbAvaliacaoQuestoesDAO =  new TbAvaliacaoQuestoesDAO();
            $tbAvaliacaoRespostasDAO =  new TbAvaliacaoRespostasDAO();
            $respostasExcluidas = $tbAvaliacaoRespostasDAO->deleteByAvaliacaoQuestao($con['treinamentosCon'],$novaQuestao->id);            
            $questaoExcluida = $tbAvaliacaoQuestoesDAO->delete($con['treinamentosCon'],$novaQuestao->id);            
            
            return array(
                "questaoExcluida"=>$questaoExcluida,
                "respostasExcluidas"=>$respostasExcluidas
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter questões!","exception"=>$e->getMessage());
        }
    }
    public function deleteResposta($con,$data){
        try{
            $novaQuestao = $data->param;
            $tbAvaliacaoRespostasDAO =  new TbAvaliacaoRespostasDAO();
            $respostaExcluida = $tbAvaliacaoRespostasDAO->delete($con['treinamentosCon'],$novaQuestao->id);
            return array(
                "respostaExcluida"=>$respostaExcluida
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter questões!","exception"=>$e->getMessage());
        }
    }
}
?>