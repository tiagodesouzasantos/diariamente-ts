<?php
class TbAvaliacaoQuestoesDAO{
    public function lista($con){
        try{
            $sql = "SELECT * FROM TB_AVALIACAO_QUESTOES";
            $statement = $con->prepare($sql);       
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    }

    public function save($con,$data){
        try{
            $sql = "INSERT INTO TB_AVALIACAO_QUESTOES ([desc],[tempo])
                    OUTPUT Inserted.id
                    VALUES (:desc,:tempo)";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":desc",$data->desc);        
            $statement->bindValue(":tempo",$data->tempo);        
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
    public function update($con,$data){
        try{
            $sql = "UPDATE TB_AVALIACAO_QUESTOES
                        SET [desc] = :desc, [tempo] = :tempo
                        WHERE id = :id";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":desc",$data->desc);        
            $statement->bindValue(":tempo",$data->tempo);        
            $statement->bindValue(":id",$data->id); 
            $con->executeQuery($statement);       
            return $data->id;
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
    public function delete($con,$id){
        try{
            $sql = "DELETE FROM TB_AVALIACAO_QUESTOES
                    WHERE id=:id";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":id",$id);        
            return count($con->executeQuery($statement))==0?true:false;       
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
}
?>



