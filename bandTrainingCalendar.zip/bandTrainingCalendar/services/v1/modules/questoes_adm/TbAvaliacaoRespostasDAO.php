<?php
class TbAvaliacaoRespostasDAO{
    public function lista($con){
        try{
            $sql = "SELECT * FROM TB_AVALIACAO_RESPOSTAS";
            $statement = $con->prepare($sql);       
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    }
    public function findByQuestao($con,$idQuestao){
        try{
            $sql = "SELECT * FROM TB_AVALIACAO_RESPOSTAS WHERE fk_avaliacao_questoes=:fk_avaliacao_questoes";
            $statement = $con->prepare($sql);      
            $statement->bindValue(":fk_avaliacao_questoes",$idQuestao);                     
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    }
    public function save($con,$data){
        try{
            $sql = "INSERT INTO TB_AVALIACAO_RESPOSTAS ([desc],[ordem],[correta],[fk_avaliacao_questoes])
                    OUTPUT Inserted.id
                    VALUES (:desc,:ordem,:correta,:fk_avaliacao_questoes)";
            $statement = $con->prepare($sql);      
            $statement->bindValue(":desc",$data->desc);                     
            $statement->bindValue(":ordem",$data->ordem);                     
            $statement->bindValue(":correta",$data->correta);                     
            $statement->bindValue(":fk_avaliacao_questoes",$data->fk_avaliacao_questoes);                     
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao salvar os dados!","exception"=>$e->getMessage);
        }
    }
    public function update($con,$data){
        try{
            $sql = "UPDATE TB_AVALIACAO_RESPOSTAS
                    SET [desc]=:desc, [ordem]=:ordem, [correta]=:correta
                    WHERE id=:id;";
            $statement = $con->prepare($sql);      
            $statement->bindValue(":desc",$data->desc);                     
            $statement->bindValue(":ordem",$data->ordem);                     
            $statement->bindValue(":correta",$data->correta);                     
            // $statement->bindValue(":fk_avaliacao_questoes",$data->fk_avaliacao_questoes);                     
            $statement->bindValue(":id",$data->id);                     
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao salvar os dados!","exception"=>$e->getMessage);
        }
    }
    public function deleteByAvaliacaoQuestao($con,$idQuestao){
        try{
            $sql = "DELETE FROM TB_AVALIACAO_RESPOSTAS 
                WHERE fk_avaliacao_questoes=:fk_avaliacao_questoes";
            $statement = $con->prepare($sql);                      
            $statement->bindValue(":fk_avaliacao_questoes",$idQuestao);                     
            return count($con->executeQuery($statement))==0?true:false;      
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao salvar os dados!","exception"=>$e->getMessage);
        }
    }
    public function delete($con,$idQuestao){
        try{
            $sql = "DELETE FROM TB_AVALIACAO_RESPOSTAS 
                WHERE id=:id";
            $statement = $con->prepare($sql);        
            $statement->bindValue(":id",$idQuestao);
            return count($con->executeQuery($statement))==0?true:false;
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao salvar os dados!","exception"=>$e->getMessage);
        }
    }


}
?>