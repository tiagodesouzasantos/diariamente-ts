<?php
class TbAvaliacaoProvaDAO{
    public function lista($con){
        try{
            $sql = "SELECT * FROM TB_AVALIACAO_PROVA";
            $statement = $con->prepare($sql);       
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    }
    public function save($con,$data){
        try{
            $sql = "INSERT INTO TB_AVALIACAO_PROVA ([desc])
                    OUTPUT Inserted.id
                    VALUES (:desc)";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":desc",$data->desc);        
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
    public function delete($con,$id){
        try{
            $sql = "DELETE FROM TB_AVALIACAO_PROVA WHERE id=:id";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":id",$id);        
            return count($con->executeQuery($statement))==0?true:false;
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
    public function update($con,$dados){
        try{
            $sql = "UPDATE TB_AVALIACAO_PROVA 
                    SET [desc]=:desc
                    WHERE id=:id";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":id",$dados->id);        
            $statement->bindValue(":desc",$dados->desc);        
            return count($con->executeQuery($statement))==0?true:false;
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
}
?>