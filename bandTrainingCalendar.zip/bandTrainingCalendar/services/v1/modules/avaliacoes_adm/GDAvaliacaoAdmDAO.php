<?php
class GDAvaliacaoAdmDAO{
    public function getQuestoesByAvaliacao($con,$idAvaliacao){
        try{
            $sql = "SELECT a.* FROM tb_avaliacao_questoes a 
                    INNER JOIN TB_AVALIACAO_PROVA_QUESTOES  b
                    ON a.id = b.fk_avaliacao_questoes
                    WHERE b.fk_avaliacao_prova=:fk_avaliacao_prova
                    ORDER BY a.id";
            $statement = $con->prepare($sql);       
            $statement->bindValue(":fk_avaliacao_prova",$idAvaliacao);   
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
    public function getRespostasAvaliacao($con,$idAvaliacaoQuestao){
        try{
            $sql = "  SELECT a.* FROM TB_AVALIACAO_RESPOSTAS a 
                        INNER JOIN TB_AVALIACAO_QUESTOES  b
                        ON a.fk_avaliacao_questoes = b.id
                        WHERE b.id=:fk_avaliacao_questoes
                        ORDER BY b.id,a.ordem";
            $statement = $con->prepare($sql);       
            $statement->bindValue(":fk_avaliacao_questoes",$idAvaliacaoQuestao);   
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
    public function getQuestoes($con){
        try{
            $sql = "SELECT * FROM TB_AVALIACAO_QUESTOES";
            $statement = $con->prepare($sql);       
            return $con->executeQuery($statement);           
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao buscar os dados!","exception"=>$e->getMessage);
        }
    } 
}
?>