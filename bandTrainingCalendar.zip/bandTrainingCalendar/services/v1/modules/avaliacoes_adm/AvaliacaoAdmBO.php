<?php
include_once 'TbAvaliacaoProvaDAO.php';
include_once 'GDAvaliacaoAdmDAO.php';
include_once 'TbAvaliacaoProvaQuestoesDAO.php';
include_once 'GDAvaliacaoAdmDAO.php';

Class AvaliacaoAdmBO{
    public $contador = 0;

    public function controller($action,$conexoes,$dados){
        switch($action){
            case 'listaAvaliacao':
                return $this->listaAvaliacao($conexoes);
            break;                      
            case 'listaQuestoesAvaliacao':
                return $this->buscaQuestoesAvaliacao($conexoes,$dados);
            break;            
            case 'listaQuestoes':
                return $this->buscaQuestoes($conexoes,$dados);
            break;            
            case 'saveAvaliacao':
                return $this->saveAvaliacao($conexoes,$dados);
            break;            
            case 'atualizaAvaliacao':
                return $this->atualizaAvaliacao($conexoes,$dados);
            break;            
            case 'deleteAvaliacao':
                return $this->deleteAvaliacao($conexoes,$dados);
            break;            
            case 'deleteQuestao':
                return $this->deleteQuestao($conexoes,$dados);
            break;            
            case 'deleteQuestaoAvaliacao':
                return $this->deleteQuestaoAvaliacao($conexoes,$dados);
            break;            
            default:
            return array();
        }
    }

    public function listaAvaliacao($conexoes){
        try{            
            $tbAvaliacaoProvaDAO = new TbAvaliacaoProvaDAO();
            $avaliacoes = $tbAvaliacaoProvaDAO->lista($conexoes['treinamentosCon']);                    
            return array("avaliacoes"=>$avaliacoes);
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }

    public function buscaQuestoesAvaliacao($conexoes,$dados){
        try{
            $gdAvaliacaoAdmDAO = new GDAvaliacaoAdmDAO();
            $questoes = $gdAvaliacaoAdmDAO->getQuestoesByAvaliacao($conexoes['treinamentosCon'],$dados->param->idAvaliacao);
            return array(
                "questoes"=>$this->getRespostas($conexoes,$questoes)
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }
    public function buscaQuestoes($conexoes,$dados){
        try{
            $gdAvaliacaoAdmDAO = new GDAvaliacaoAdmDAO();
            $questoes = $gdAvaliacaoAdmDAO->getQuestoes($conexoes['treinamentosCon']);
            return array(
                "questoes"=>$this->getRespostas($conexoes,$questoes)
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }
    public function getRespostas($conexoes,$questoes){
        try{
            $gdAvaliacaoAdmDAO = new GDAvaliacaoAdmDAO();
            for($i=0;$i<count($questoes);$i++){
                $questoes[$i]['respostas'] = $gdAvaliacaoAdmDAO->getRespostasAvaliacao($conexoes['treinamentosCon'],$questoes[$i]['id']);
            }
            return $questoes;
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }
    public function saveAvaliacao($conexoes,$dados){
        try{
            $tbAvaliacaoProvaDAO = new TbAvaliacaoProvaDAO();
            $tbAvaliacaoProvaQuestoesDAO = new TbAvaliacaoProvaQuestoesDAO();
            $questoesData = $dados->param->avaliacaoQuestoes->questoesSelecionadas;
            $avaliacaoData = $dados->param->avaliacaoQuestoes->avaliacao;
            $avaliacaoSalva = $tbAvaliacaoProvaDAO->save($conexoes['treinamentosCon'],$avaliacaoData);
            $arrayQuestoes = array();
            for($i=0;$i<count($questoesData);$i++){
                $questaoAvaliacao = array(
                        "fk_avaliacao_questoes"=>$questoesData[$i]->id,
                        "fk_avaliacao_prova"=>$avaliacaoSalva[0]['id']
                );                
                array_push(
                    $arrayQuestoes,
                    $tbAvaliacaoProvaQuestoesDAO->save($conexoes['treinamentosCon'],json_decode(json_encode($questaoAvaliacao),FALSE))
                );
            }
            return array(
                "questoes"=>$arrayQuestoes,
                "avaliacao"=>$avaliacaoSalva,
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }
    public function atualizaAvaliacao($conexoes,$dados){
        try{
            $tbAvaliacaoProvaDAO = new TbAvaliacaoProvaDAO();
            $tbAvaliacaoProvaQuestoesDAO = new TbAvaliacaoProvaQuestoesDAO();
            $questoesData = $dados->param->questoesSelecionadas;
            $avaliacaoData = $dados->param->avaliacao;
            $avaliacaoSalva = $tbAvaliacaoProvaDAO->update($conexoes['treinamentosCon'],$avaliacaoData);
            $arrayQuestoes = array();
            for($i=0;$i<count($questoesData);$i++){
                $questaoAvaliacao = array(
                        "fk_avaliacao_questoes"=>$questoesData[$i]->id,
                        "fk_avaliacao_prova"=>$avaliacaoSalva[0]['id']
                );                
                // array_push(
                //     $arrayQuestoes,
                //     $tbAvaliacaoProvaQuestoesDAO->save($conexoes['treinamentosCon'],json_decode(json_encode($questaoAvaliacao),FALSE))
                // );
            }
            return array(
                "questoes"=>$arrayQuestoes,
                "avaliacao"=>$avaliacaoSalva,
                "questoesData"=>$questoesData,
                "avaliacaoData"=>$avaliacaoData,
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }
    public function deleteAvaliacao($conexoes,$dados){
        try{
            $idAvaliacao = $dados->param->id;
            $tbAvaliacaoProvaDAO = new TbAvaliacaoProvaDAO();
            $tbAvaliacaoProvaQuestoesDAO = new TbAvaliacaoProvaQuestoesDAO();
            $questoes = $tbAvaliacaoProvaQuestoesDAO->deleteAvaliacao($conexoes['treinamentosCon'],$idAvaliacao);
            $avaliacao = $tbAvaliacaoProvaDAO->delete($conexoes['treinamentosCon'],$idAvaliacao);
            return array(
                "removido"=>($questoes && $avaliacao)?true:false
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas em remover avaliações!","exception"=>$e->getMessage());
        }
    }
    public function deleteQuestaoAvaliacao($conexoes,$dados){
        try{
            $questaoAvaliacao = $dados->param;
            $tbAvaliacaoProvaQuestoesDAO = new TbAvaliacaoProvaQuestoesDAO();
            $questao = $tbAvaliacaoProvaQuestoesDAO->deleteQuestao($conexoes['treinamentosCon'],json_decode(json_encode($questaoAvaliacao),FALSE));
            return array(
                "removido"=>$questao
            );
        }catch(\Exception $e){
            return array("error"=>"Problemas ao obter avaliações!","exception"=>$e->getMessage());
        }
    }
    
}
?>