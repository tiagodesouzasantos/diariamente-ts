<?php
class TbAvaliacaoProvaQuestoesDAO{
    public function save($con,$data){
        try{
            $sql = "INSERT INTO TB_AVALIACAO_PROVA_QUESTOES (fk_avaliacao_prova,fk_avaliacao_questoes)
                    OUTPUT Inserted.id,Inserted.fk_avaliacao_prova,Inserted.fk_avaliacao_questoes
                    VALUES (:fk_avaliacao_prova,:fk_avaliacao_questoes)";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":fk_avaliacao_prova",$data->fk_avaliacao_prova);        
            $statement->bindValue(":fk_avaliacao_questoes",$data->fk_avaliacao_questoes);        
            return $con->executeQuery($statement);
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao inserir os dados!","exception"=>$e->getMessage);
        }
    } 
    public function deleteAvaliacao($con,$idAvaliacao){
        try{
            $sql = "DELETE FROM TB_AVALIACAO_PROVA_QUESTOES 
                    WHERE fk_avaliacao_prova=:fk_avaliacao_prova";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":fk_avaliacao_prova",$idAvaliacao);              
            return count($con->executeQuery($statement))==0?true:false;
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao inserir os dados!","exception"=>$e->getMessage);
        }
    } 
    public function deleteQuestao($con,$data){
        try{
            $sql = "DELETE FROM TB_AVALIACAO_PROVA_QUESTOES 
                    WHERE fk_avaliacao_prova=:fk_avaliacao_prova
                    AND fk_avaliacao_questoes=:fk_avaliacao_questoes";
            $statement = $con->prepare($sql);  
            $statement->bindValue(":fk_avaliacao_prova",$data->fk_avaliacao_prova);              
            $statement->bindValue(":fk_avaliacao_questoes",$data->fk_avaliacao_questoes);
            return count($con->executeQuery($statement))==0?true:false;  
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao inserir os dados!","exception"=>$e->getMessage);
        }
    } 
}
?>