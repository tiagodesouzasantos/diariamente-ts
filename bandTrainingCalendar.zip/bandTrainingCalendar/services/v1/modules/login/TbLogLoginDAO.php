<?php
class TbLogLoginDAO{
    public function save($con,$id_usuario){
        try{
            $sql = "INSERT INTO TB_LOG_LOGIN (id_usuario) VALUES (:id_usuario)";
            $statement = $con->prepare($sql);
            $statement->bindValue(":id_usuario",$id_usuario);
            return $con->executeQuery($statement);
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao inserir os dados!","exception"=>$e->getMessage);
        }
    }
}
?>