<?php
class ConfigsUsuarioDAO{
    public function getMenus($con,$id){
        try{
            $sql = "
            SELECT DISTINCT d.* FROM  TB_USUARIO_PERFIL_ACESSO b               
                INNER JOIN TB_PERFIL_MENU_ACESSO c
                on b.fk_perfil_acesso = c.fk_perfil_acesso
                INNER JOIN TB_MENU_ACESSO d
                on d.id = c.fk_menu_acesso
                WHERE b.fk_usuario=:id;
            ";
            $statement = $con->prepare($sql);
            $statement->bindValue(":id",$id);            
            $result = $con->executeQuery($statement);        
            return $result;
        }catch(\Exception $e){
            return array("erro"=>"Problemas ao consultar os dados!","exception"=>$e->getMessage);
        }
    }
}
?>