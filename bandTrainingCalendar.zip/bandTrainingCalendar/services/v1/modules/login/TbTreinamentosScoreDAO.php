<?php
class TbTreinamentosScoreDAO{
    public function find($con,$id){
        try{
            $sql = "SELECT * FROM TB_TREINAMENTOS_SCORE WHERE fk_usuario=:fk_usuario";
            $statement = $con->prepare($sql);
            $statement->bindValue(":fk_usuario",$id);                    
            $result = $con->executeQuery($statement);        
            return $result[0];
        }catch(\Exception $e){
            throw new Exception($e->getMessage());
        }
    }
}
?>