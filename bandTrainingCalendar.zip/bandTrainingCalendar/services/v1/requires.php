<?php
require_once "modules/login/LoginBO.php";
require_once "modules/vetorh/VetorhBO.php";
require_once "modules/avaliacoes-reacao/AvaliacaoReacaoBO.php";
require_once "modules/avaliacoes/AvaliacaoBO.php";
require_once "modules/avaliacoes_adm/AvaliacaoAdmBO.php";
require_once "modules/questoes_adm/QuestoesAdmBO.php";
require_once "DBO/Conexao.php";
?>