<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST,GET,OPTIONS');
header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');
//ini_set('default_charset', 'UTF-8');
error_reporting(0);
//ob_start();
require_once "requires.php";

try{
    $postdata = file_get_contents("php://input");

    if($postdata==""){
        $postdata = $_REQUEST;
        $request = json_decode(json_encode($postdata));
    }else{
        $request = json_decode($postdata);
    }    
    $conexoes = array(
        "treinamentosCon"=>new Conexao('treinamentos'),
        "vetorhCon"=>new Conexao('vetorh'),
        "usuarioCon"=>new Conexao('usuariosband')
    );   
    switch ($request->modulo) {
        case 'avaliacoesReacao':                   
            $avaliacaoReacaoBO = new AvaliacaoReacaoBO();            
            echo json_encode($avaliacaoReacaoBO->controller($request->acao,$conexoes,$request));       
        break;    
        case 'avaliacoes':                   
            $avaliacaoBO = new AvaliacaoBO();            
            echo json_encode($avaliacaoBO->controller($request->acao,$conexoes,$request));       
        break;    
        case 'avaliacoes_adm':                   
            $avaliacaoAdmBO = new AvaliacaoAdmBO();            
            echo json_encode($avaliacaoAdmBO->controller($request->acao,$conexoes,$request));       
        break;    
        case 'login':                     
            $loginBO = new LoginBO();            
            echo json_encode($loginBO->controller($request->acao,$conexoes,$request));
            break;   
        case 'treinamento-vetorh':
            $vetorhBO = new VetorhBO();
            echo json_encode($vetorhBO->controller($request->acao,$conexoes,$request));
            break;   
        case 'questoes_adm':
            $questoesAdmBO = new QuestoesAdmBO();
            echo json_encode($questoesAdmBO->controller($request->acao,$conexoes,$request));
            break;   
        default :
            echo json_encode(
                array(
                    "error"=>"Por favor selecione uma ação!"
                )
            );
    }    
}catch(\Exception $e){
    echo json_encode(
            array(
                "error"=>"Por favor selecione uma ação!",
                "exception"=>$e->getMessage()
            )
        );
}

