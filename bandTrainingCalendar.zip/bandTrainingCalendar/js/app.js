angular.module('bandTrainingCalendar', [
    'ngMaterial',
    'ngAnimate',
    'performance',
    'ngSanitize',
    'ui.router',
    'gridster',
    'ui.carousel',
    'chart.js',
    'home',
    'menu',
    'instrutor',
    'admin',
    'initial',
    'rzModule',
    'dbServer',
    'mapsService',
    'timeService',
    'materialCalendar',
    'treinamento',
    'text',
    'recoverPass',
    'meusDados'
])

.config(["$mdThemingProvider", "$stateProvider", "$urlRouterProvider", "$mdDateLocaleProvider", function($mdThemingProvider, $stateProvider, $urlRouterProvider, $mdDateLocaleProvider) {



    // Configuração de tema do Angular Material
    $mdThemingProvider
        .theme('default')
        .primaryPalette('light-blue')
        .accentPalette('light-blue');

    // Configuração de rotas
    $stateProvider
        .state('initial', {
            url: '/initial',
            views: {
                'content@': {
                    templateUrl: 'modules/initial/index.html',
                    controller: 'initialController as initial'
                }
            }
        })

    $stateProvider
        .state('recoverpass', {
            url: '/recoverpass/:recoverpass',
            views: {
                'content@': {
                    templateUrl: 'modules/recoverpass/index.html',
                    controller: 'recoverPassController as recoverPass'
                }
            }
        })

    .state('menu', {
        abstract: true,
        views: {
            'content@': {
                templateUrl: 'modules/menu/index.html',
                controller: 'menuController as menu'
            }
        }
    })

    // INICIO PUBLICACOES
    .state('home', {
            parent: 'menu',
            url: '/home',
            views: {
                'main@menu': {
                    templateUrl: 'modules/home/index.html',
                    controller: 'homeController as home'
                }
            }
        })
        .state('treinamento', {            
            parent: 'menu',
            url: '/treinamento',
            params: { treinamento: null},
            cache: false,
            views: {
                'main@menu': {
                    templateUrl: 'modules/treinamento/index.html',
                    controller: 'treinamentoController as treinamento'
                }
            }
        })

        .state('meusDados', {
            parent: 'menu',
            url: '/meusDados',
            views: {
                'main@menu': {
                    templateUrl: 'modules/meusDados/index.html',
                    controller: 'meusDadosController as meusDados'
                }
            }
        })
        .state('admin', {
            parent: 'menu',
            url: '/admin',
            views: {
                'main@menu': {
                    templateUrl: 'modules/admin/index.html',
                    controller: 'adminController as admin'
                }
            }
        })
        .state('instrutor', {
            parent: 'menu',
            url: '/instrutor',
            views: {
                'main@menu': {
                    templateUrl: 'modules/instrutor/index.html',
                    // controller: 'instrutorController as instrutor'
                }
            }
        })



    $urlRouterProvider.otherwise('initial');
    //Formato Brazileiro date
    $mdDateLocaleProvider.formatDate = function(dateString) {
        var data;
        if (dateString === undefined) {
            data = '';
        } else {
            data = moment(dateString).format('DD/MM/YYYY');
        }
        return data;
    };

    $mdDateLocaleProvider.parseDate = function(dateString) {
        var m = moment(dateString, 'DD/MM/YYYY', true);
        return m.isValid() ? m.toDate() : new Date(NaN);
    };

    //Tradução Calendar
    $mdDateLocaleProvider.months = ['janeiro', 'fereveiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
    $mdDateLocaleProvider.shortMonths = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    $mdDateLocaleProvider.shortDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'];

}]).run(["$rootScope", "$state", "session", function($rootScope, $state, session) {

    var routerWithLogin = ['home', 'menu', 'treinamento', 'meusDados', 'admin', 'instrutor'];

    $rootScope.$on('$locationChangeSuccess', function(event, next, current) {
        for (var route in routerWithLogin) {
            var foundedUrl = next.indexOf(routerWithLogin[route]);
            if (foundedUrl >= 0) {
                var splitedUrl = next.substr((foundedUrl), next.length).split('/');
                if (routerWithLogin[route] == splitedUrl[(splitedUrl.length - 1)]) {
                    session.valideSession(routerWithLogin[route]);
                    break;
                }
            }
        }
        var url = next.split('/');
        $rootScope.labelColors = url[4] == "home"?true:false;
    })
}]);;angular.module('dbServer', [])
angular.module('mapsService', [])
angular.module('sessionService', [])
angular.module('timeService', [])

angular.module('menu', [])
angular.module('admin', [])
angular.module('instrutor', [])
angular.module('text', [])

angular.module('initial', [])
angular.module('performance', [])
angular.module('meusDados', [])
angular.module('treinamento', [])
angular.module('recoverPass', [])
angular.module('home', [ 'dbServer']);angular.module('initial')
    .controller('initialController',
    ["$scope", "$state", "$rootScope", "initialService", "dialogService", "$mdDialog", "msgsService", function ($scope, $state, $rootScope, initialService, dialogService, $mdDialog, msgsService) {
            $scope.init = function() {
                console.log('%c Que coisa feia inspecionando o app né! ', 'background: #222; color: #bada55');
            }
            $scope.submit = function() {
                $rootScope.showLoading = true;
                initialService.login($scope.login).then(function(authUsuarioResult) {
                    $rootScope.showLoading = false;
                    if (authUsuarioResult.validPass && authUsuarioResult.userExist){
                        $state.go('home');
                    }
                }).catch(function(authUsuarioError) {
                    $rootScope.showLoading = false;
                    var confirmeJson = {
                        "title": "Problemas!",
                        "content": authUsuarioError.msgError,
                        "buttonOk": "Ok"
                    };	
                    if(authUsuarioError.userRH!=null){
                        confirmeJson.content = authUsuarioError.msgError;
                        $scope.usuarioRH = authUsuarioError.userRH;
                    }
                    dialogService.confirm(confirmeJson);
                });
            }        
        
            $scope.openDialog = function (template) {
                $scope.login = null;
                var templates = { 
                    "rsenha": 'modules/initial/recuperar-senha.html',
                    "cadastre": 'modules/initial/cadastre-se.html' 
                }
                return $mdDialog.show({
                    controller: ["copiaScope", function (copiaScope) {
                        return copiaScope;
                    }],
                    controllerAs: 'initial',
                    locals: {
                        copiaScope: $scope
                    },
                    templateUrl: templates[template],
                    clickOutsideToClose: true
                });
            }

            $scope.closeModal = function () {
                $mdDialog.hide();
            }
            
            $scope.getUserDataByCpf = function(){
                $scope.errorMsg = null;
                initialService.login($scope.login).then(function (authUsuarioResult) {  
                }).catch(function (authUsuarioError) {                    
                    var error = authUsuarioError;
                    if (error.userExist) {
                        $scope.errorMsg = msgsService.getMsg('usuario',2);                        
                        $scope.login.nome = null;                     
                    }else if (error.userRH != null) {
                        $scope.login = error.userRH;                                                
                    } else if (error.userExist == false && error.userRH == null && error.validPass==false){
                        $scope.errorMsg = error.msgError;
                        $scope.login.nome = null;                     
                    }
                });
            }

            $scope.saveNewUser = function(){
                $scope.progress = true;                
                var save = initialService.saveNewUser($scope.login);
                save.then(function (saveResult) { 
                    $scope.progress = false;
                    var confirmeJson = {
                        "title": "Deu certo!",
                        "content": saveResult,
                        "buttonOk": "Ok"
                    };	
                    dialogService.confirm(confirmeJson);
                }).catch(function (saveError) { 
                    $scope.errorMsg = saveError;
                    var confirmeJson = {
                        "title": "Algo aconteceu!",
                        "content": saveResult,
                        "buttonOk": "Ok"
                    };
                    dialogService.confirm(confirmeJson);
                });
            }

            $scope.recoverPass = function(){
                $scope.progress = true;
                var recover = initialService.recoverPass($scope.login);
                var confirmeJson = {
                    "title": "Deu certo!",
                    "content": "",
                    "buttonOk": "Ok"
                };
                recover.then(function (recoverResult) {
                    confirmeJson.content = recoverResult;
                    dialogService.confirm(confirmeJson);
                    $scope.progress = false;
                }).catch(function (recoverError) {
                    confirmeJson.title = "Problemas!";
                    confirmeJson.content = recoverError;                    
                    dialogService.confirm(confirmeJson);
                    $scope.progress = false;
                });
            }
        }]);;angular.module('initial')
    .service('initialService',
        ["$q", "$http", "db", "msgsService", "auth", function($q, $http, db, msgsService, auth) {
            return {
                validaUsuario: function(usuario) {
                    var validaUsuarioProm = $q.defer();
                    if (usuario != null || usuario != undefined) {
                        validaUsuarioProm.resolve(usuario);
                    } else {
                        var confirmeJson = {
                            "title": "Problemas!",
                            "content": msgsService.getMsg('usuario', 1),
                            "buttonOk": "Ok"
                        };
                        validaUsuarioProm.reject(confirmeJson);
                    }
                    return validaUsuarioProm.promise;
                },
                login: function(usuario) {
                    var authProm = $q.defer();
                    usuario.acao = "auth";
                    usuario.modulo = "login";
                    auth.login(usuario).then(function(authResult) {
                        if (authResult.msgError){
                            authProm.reject(authResult);
                        }else{
                            authProm.resolve(authResult);
                        }
                        // console.log('authResult', authResult);
                    }).catch(function(authError) {
                        authProm.reject(authError);
                    });

                    return authProm.promise;
                },
                saveNewUser:function(usuario){
                    var saveNewUserProm = $q.defer();
                    db.dbActions('newUser', usuario, 'login')
                    .then(function (saveResult) {
                        // console.log('salvando usuario', saveResult);
                        if (saveResult.created){
                            saveNewUserProm.resolve(msgsService.getMsg('app', 1));
                        }else{
                            var msg;
                            if (saveResult.userExist){
                                msg = msgsService.getMsg('app', 2);
                            } else if (!saveResult.colab){
                                msg = msgsService.getMsg('app', 4);
                            }
                            saveNewUserProm.reject(msg);
                        }
                    }).catch(function (saveError) {
                        saveNewUserProm.reject(msgsService.getMsg('app', 3));
                    });
                    return saveNewUserProm.promise;
                },
                recoverPass:function(usuario){
                    var recoverPassProm = $q.defer();
                    db.dbActions('recoverPass', usuario, 'login')
                        .then(function (recoverResult) {                            
                            recoverPassProm.resolve(msgsService.getMsg('app', 11));
                        }).catch(function (recoverError) {
                            recoverPassProm.reject(msgsService.getMsg('app', 3));
                        });
                    return recoverPassProm.promise;
                }
            }
        }]
    );angular.module('recoverPass')
    .controller('recoverPassController',
    ["$scope", "$state", "recoverPassService", "dialogService", "$stateParams", function ($scope, $state, recoverPassService, dialogService, $stateParams) {
            $scope.init = function() {
                console.log('%c Que coisa feia inspecionando o app né! ', 'background: #222; color: #bada55');
                $scope.authToken();
                $scope.progress = false;
            }
            $scope.authToken = function() {
                var token = { "hash": $stateParams.recoverpass};
                var recoverpass = recoverPassService.getToken(token);
                recoverpass.then(function (recoverResult) { 
                    $scope.login = recoverResult;
                }).catch(function (recoverError) { 
                    var confirmeJson = {
                        "title": "Problemas!",
                        "content": recoverError,
                        "buttonOk": "Ok"
                    };
                    dialogService.confirm(confirmeJson)
                        .then(function(){
                            $state.go('initial');
                        });
                });
            }        
        
            $scope.updatePass = function(){
                $scope.progress = true;
                var token = { "hash": $stateParams.recoverpass };
                var recoverpass = recoverPassService.updatePass($scope.login);
                recoverpass.then(function (recoverResult) {  
                    $scope.progress = false;
                    var confirmeJson = {
                        "title": "Deu certo!",
                        "content": recoverResult,
                        "buttonOk": "Ok"
                    };
                    dialogService.confirm(confirmeJson)
                        .then(function () {
                            $state.go('initial');
                        });                 
                }).catch(function (recoverError) {
                    $scope.progress = false;
                    var confirmeJson = {
                        "title": "Problemas!",
                        "content": recoverError,
                        "buttonOk": "Ok"
                    };
                    dialogService.confirm(confirmeJson)
                        .then(function () {
                            $state.go('initial');
                        });
                });
            }

        }]);;angular.module('recoverPass')
    .service('recoverPassService',
        ["$q", "$http", "db", "msgsService", function($q, $http, db, msgsService) {
            return {                
                getToken: function(token) {
                    var getTokenProm = $q.defer();
                    db.dbActions('getToken', token, 'login')
                        .then(function (tokenResult) {
                            if (tokenResult.validToken){
                                getTokenProm.resolve(tokenResult);
                            }else{
                                getTokenProm.reject(msgsService.getMsg('usuario', 6));
                            }
                        }).catch(function (tokenError) {
                            getTokenProm.reject(msgsService.getMsg('app', 3));
                        });
                    return getTokenProm.promise;
                },
                updatePass: function(user) {
                    var updatePassProm = $q.defer();
                    db.dbActions('updatePass', user, 'login')
                        .then(function (updateResult) {
                            if (updateResult.updated && updateResult.deleted){
                                updatePassProm.resolve(msgsService.getMsg('app', 1));
                            }else{
                                updatePassProm.reject(msgsService.getMsg('usuario', 3));
                            }
                        }).catch(function (updateError) {
                            updatePassProm.reject(msgsService.getMsg('usuario', 3));
                        });
                    return updatePassProm.promise;
                }
            }
        }]
    );angular.module('home')
    .controller('homeController',
        ["$filter", "$state", "$scope", "homeService", "$rootScope", "$mdDialog", "dateService", "$q", function($filter, $state, $scope, homeService, $rootScope, $mdDialog, dateService,$q) {
            $scope.init = function() {
                $rootScope.showLoading = true;
                $scope.limitDesc = 80;
                $scope.calendario = false;
                $scope.progress = false;
                $scope.tooltips = true;
                $scope.desabilitado = true;
                $scope.selectedDate = null;
                $scope.firstDayOfWeek = 0;
                $scope.getDateCalendar();
                $scope.loadData();
                homeService.limpTreinCanc()
            }
            
            $scope.loadData = function() {
                var datas = {"treinamentos": homeService.getTreinamentos()};
                $q.all(datas).then(function(datasResult){ 
                    console.log('datasResult',datasResult);                
                    $scope.datejson = datasResult.treinamentos.calendario;
                    $scope.treinamentosDoDia = datasResult.treinamentos.dataTreinamentos;
                    $scope.treinamentosColab = datasResult.treinamentos.treinamentosColab;
                    $scope.calendario = true;
                    $rootScope.showLoading = false;
                }).catch(function(datasError){
                    console.log('datasError',datasError);
                });
            }
            $scope.getDateCalendar = function(){
                var data = dateService.formatDateDB(new Date());
                data = data.split('-');
                $scope.data = { "m": data[1], "y": data[0]};
                // console.log('$scope.data', $scope.data);
            }

            $scope.dialogListaVinculados = function(lista) {
                $scope.listaAtual = $scope.treinamentosColab[lista.id_treinamento][lista.id_turma];
                // console.log('lista', $scope.listaAtual);
                return $mdDialog.show({
                    controller: ["copiaScope", function(copiaScope) {
                        return copiaScope;
                    }],
                    controllerAs: 'home',
                    locals: {
                        copiaScope: $scope
                    },
                    templateUrl: 'modules/home/lista-vinculados.html',
                    clickOutsideToClose: true
                }).then(function(){}).catch(function(){
                    $scope.searchList = '';
                });
            }

            $scope.closeModal = function() {
                $mdDialog.hide();
            }

            $scope.addColaboradores = function(treinamento) {                
                treinamento.btnCancelar = homeService.getTagColorTraining(treinamento);
                treinamento.colaboradores = $scope.treinamentosColab[treinamento.id_treinamento][treinamento.id_turma];
                $state.go('treinamento',{"treinamento":treinamento});
            };
            $scope.dayClick = function(date) {                
                $scope.diaSelecionado = $filter("date")(date, "dd/MM/yy");            
                $scope.selectedDateDB = $filter("date")(date, "yyyy-MM-dd");
                // var datejson = treinamentosFake;
                $scope.treinamentos = $scope.treinamentosDoDia[$scope.selectedDateDB];
            };
            $scope.prevMonth = function(data) {
                $scope.msg = "You clicked (prev) month " + data.month + ", " + data.year;
            };
            $scope.nextMonth = function(data) {
                $scope.msg = "You clicked (next) month " + data.month + ", " + data.year;
            };


            $scope.setDayContent = function(date) {
                var dateDB = dateService.formatDateDB(date);
                var contentDate = "";

                if ($scope.datejson[dateDB] != undefined) {
                    contentDate = $scope.datejson[dateDB];
                }
                return contentDate;
            };
        }]);;angular.module('home')
    .service('homeService',
    ["$q", "db", "session", "msgsService", function ($q, db, session, msgsService) {
            return {
                getTreinamentos:function(){
                    var treinamentosProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": "listaTreinamentos", "usuario": JSON.parse(session.getData('authData'))}, 'treinamento-vetorh')
                        .then(function (treinamentosResult) {                            
                            treinamentosProm.resolve(treinamentosResult);
                        }).catch(function (treinamentosError) {
                            console.log('gettreinamentos-error', treinamentosError);
                            treinamentosProm.reject(msgsService.getMsg('app', 3));
                        });
                    return treinamentosProm.promise;
                },
                limpTreinCanc:function(){
                    var limpTreinCancProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": "limpTreinCanc", "usuario": JSON.parse(session.getData('authData'))}, 'treinamento-vetorh')
                        .then(function (limpTreinCancResult) {     
                            // console.log('limpTreinCancResult', limpTreinCancResult);
                            limpTreinCancProm.resolve(limpTreinCancResult);
                        }).catch(function (limpTreinCancError) {
                            console.log('getlimpTreinCanc-error', limpTreinCancError);
                            limpTreinCancProm.reject(msgsService.getMsg('app', 3));
                        });
                    return limpTreinCancProm.promise;
                },
                getTagColorTraining:function(treinamento){
                    var id = 'tag' + treinamento.id_treinamento + '' + treinamento.id_turma;
                    var htmlTag = angular.element(document.querySelector('#' + id)).attr('class').split(' ');
                    return htmlTag[1] == 'purple-tag'?true:false;
                }
            }
        }]
    );angular.module('admin')
    .controller('adminController',
        ["$state", "$scope", "session", function($state, $scope, session) {
            $scope.init = function() {
                $scope.maxDate = new Date();                
                $scope.inicial = new Date();
                $scope.final = new Date();
            }
        }]);;angular.module('admin')
    .service('adminService',
        ["$q", "$http", "db", "session", "$timeout", function($q, $http, db, session, $timeout) {
            return {
                admin: function() {    
                    return 'oi'                ;
                }
            }
        }]
    );angular.module('instrutor')
    .controller('instrutorController',
        ["$state", "session", function($state, session) {
            var instCtrl = this;
            instCtrl.init = function() {
                console.log('instrutorController');
            }
            
        }]);;angular.module('instrutor')
    .service('instrutorService',
        ["$q", "$http", "db", "session", "$timeout", function($q, $http, db, session, $timeout) {
            return {
                instrutor: function() {    
                    return 'oi'                ;
                }
            }
        }]
    );angular.module('instrutor')
    .controller('instrutorAvaliacaoController',
    ["$rootScope", "$state", "session", "instrutorAvaliacaoService", "$mdDialog", "$element", "$scope", function ($rootScope, $state, session, instrutorAvaliacaoService, $mdDialog, $element,$scope) {
            var instAvalCtrl = this;
            instAvalCtrl.init = function () {
                instAvalCtrl.loadAvaliacoes();
                instAvalCtrl.questoes = null;
                instAvalCtrl.cardSelecionado = null;
                instAvalCtrl.progress = false;
                instAvalCtrl.avaliacaoEmEdicao = false;
            }
            instAvalCtrl.loadAvaliacoes = function(){
                $rootScope.showLoading = true;
                var avaliacoes = instrutorAvaliacaoService.getListaAvaliacao();
                avaliacoes.then(function (listaAvaliacaoResult) {
                    instAvalCtrl.getListaAvaliacao = listaAvaliacaoResult.avaliacoes;
                    $rootScope.showLoading = false;
                }).catch(function (listaAvaliacaoError) {
                    $rootScope.showLoading = false;                     
                    console.log('listaAvaliacaoError', listaAvaliacaoError);
                });
            }
            instAvalCtrl.autoCompleteDescAva = function (desc) {
                instAvalCtrl.novaavaliacao = desc.desc;
            }
            instAvalCtrl.getQuestoes = function(item){
                $rootScope.showLoading = true;
                instAvalCtrl.cardSelecionado = item;
                instAvalCtrl.indexCard = item.id; 
                var questoes = instrutorAvaliacaoService.getListaQuestoesAvaliacao(instAvalCtrl.cardSelecionado);
                questoes.then(function(questoesResult){
                    instAvalCtrl.questoes = questoesResult.questoes;
                    $rootScope.showLoading = false; 
                }).catch(function (questoesError) { 
                    $rootScope.showLoading = false;                    
                });
            }
            instAvalCtrl.clearQuest = function(){
                instAvalCtrl.questoes = null;
                instAvalCtrl.indexCard = null;
            }
            
            instAvalCtrl.loadDataAbreDialog = function (template) {
                switch (template) {
                    case 'novaAvaliacao':
                        instAvalCtrl.loadNovaAvaliacao(template);
                        break;
                    default:
                        console.log('Escolha uma ação');
                }
            }

            instAvalCtrl.closeDialog = function(){
                $mdDialog.hide();
            }
            instAvalCtrl.openDialog = function(template){
                var templates = {
                    "novaAvaliacao": 'modules/instrutor/templates/novaAvaliacao.html'
                }
                return $mdDialog.show({
                    controller: ["copiaScope", function (copiaScope) {
                        return copiaScope;
                    }],
                    controllerAs: 'instAvalCtrl',
                    locals: {
                        copiaScope: instAvalCtrl
                    },
                    templateUrl: templates[template],
                    clickOutsideToClose: true
                }).then(function (modalResult) { 
                    instAvalCtrl.nva = {};
                }).catch(function (modalError) { 
                    instAvalCtrl.nva = {};
                });
            }           
            instAvalCtrl.loadNovaAvaliacao = function(template){
                $rootScope.showLoading = true;                
                var questoes = instrutorAvaliacaoService.getQuestoesData();
                questoes.then(function(getQuestoesResult){
                    instAvalCtrl.listaQuestoes = getQuestoesResult.questoes;
                    $rootScope.showLoading = false;  
                    instAvalCtrl.openDialog(template);  
                }).catch(function (getQuestoesError) {
                    console.log('getQuestoesError', getQuestoesError);
                });
            }   
            
            instAvalCtrl.editAvaliacao = function(avaliacao){
                instAvalCtrl.avaliacaoEmEdicao = true;
                instAvalCtrl.nva = { 
                    "avaliacao": avaliacao,
                    "questoesSelecionadas": instAvalCtrl.questoes
                };
                instAvalCtrl.loadNovaAvaliacao('novaAvaliacao');
            }
            instAvalCtrl.atualizandoAvalSelectOptions = function(id){
                for (var i = 0; i < instAvalCtrl.nva.questoesSelecionadas.length;i++){
                    if(instAvalCtrl.nva.questoesSelecionadas[i].id==id){
                        return true;
                    }
                }                   
                return false;
            }
            instAvalCtrl.saveAvaliacao = function(){
                instAvalCtrl.progress = true;
                console.log('instAvalCtrl.nva', instAvalCtrl.nva);
                // var save = instrutorAvaliacaoService.saveAvaliacao(instAvalCtrl.nva);
                // save.then(function (saveAvaliacaoResult) {
                //     instAvalCtrl.progress = false;
                //     instAvalCtrl.closeDialog();
                //     instAvalCtrl.init();
                // }).catch(function (saveAvaliacaoError) {
                //     console.log('saveAvaliacaoError', saveAvaliacaoError);
                // });
            }
            instAvalCtrl.atualizaAvaliacao = function(){
                instAvalCtrl.progress = true;                
                var atualizar = instrutorAvaliacaoService.atualizaAvaliacao(instAvalCtrl.nva);
                atualizar.then(function (atualizarAvaliacaoResult) {
                    instAvalCtrl.progress = false;
                    // instAvalCtrl.closeDialog();
                    // instAvalCtrl.init();
                    // console.log('atualizarAvaliacaoResult', atualizarAvaliacaoResult);

                }).catch(function (atualizarAvaliacaoError) {
                    console.log('atualizarAvaliacaoError', atualizarAvaliacaoError);
                });
            }
            instAvalCtrl.deleteAvaliacao = function(idAvaliacao){                
                var deleta = instrutorAvaliacaoService.deleteAvaliacao(idAvaliacao);
                deleta.then(function (deletaResult) {
                    instAvalCtrl.init();                  
                }).catch(function (deletaError) {
                    console.log('deletaError', deletaError);
                });
            }
            instAvalCtrl.deleteQuestaoAvaliacao = function (idAvaliacao,idQuestao,index){                
                $rootScope.showLoading = true;                                
                var deleta = instrutorAvaliacaoService.deleteQuestaoAvaliacao({ "fk_avaliacao_prova": idAvaliacao, "fk_avaliacao_questoes": idQuestao});
                deleta.then(function (deletaResult) {
                    instAvalCtrl.questoes.splice(index, 1);
                    $rootScope.showLoading = false;                    
                }).catch(function (deletaError) {
                    console.log('deletaError', deletaError);
                });
            }
        }]);;angular.module('instrutor')
    .controller('questoesController',
        ["$rootScope", "$state", "session", "$mdDialog", "questoesService", function ($rootScope, $state, session, $mdDialog,questoesService) {
            var questCtrl = this;
            questCtrl.init = function(){
                questCtrl.initVars();
                questCtrl.loadQuestoes(); 
                questCtrl.nvaInit();    
            }
            questCtrl.initVars = function(){
                questCtrl.progress = false;
                questCtrl.respostas = null;
                questCtrl.qstSelecionada = null;
                questCtrl.indexResp = null;
            }
            questCtrl.nvaInit = function(){
                questCtrl.modoEdicao = false;
                questCtrl.respostaPadrao = { "desc": "", "ordem": 0, "correta": 0 };
                questCtrl.nva = {};
                questCtrl.nva.respostas = [JSON.parse(JSON.stringify(questCtrl.respostaPadrao))];
            }

            questCtrl.addResposta = function(){
                var novaResposta = [];
                questCtrl.respostaPadrao.ordem++;
                questCtrl.nva.respostas.push(JSON.parse(JSON.stringify(questCtrl.respostaPadrao)));                
            }

            questCtrl.loadQuestoes = function(){
                $rootScope.showLoading = true;
                var questoes = questoesService.getQuestoes();
                questoes.then(function (questoesResult) { 
                    console.log('questoesResult', questoesResult);
                    questCtrl.questoesList = questoesResult;
                    $rootScope.showLoading = false;                    
                }).catch(function (questoesError) { 
                    console.log('questoesError', questoesError);
                });
            }
            questCtrl.getRespostas = function(item){
                questCtrl.qstSelecionada = item;
                questCtrl.indexResp = item.id;
                questCtrl.respostas = item.respostas;
            }
            questCtrl.clearResp = function(){
                questCtrl.respostas = null;
                questCtrl.indexResp = null;
                questCtrl.qstSelecionada = null;                
            }
            questCtrl.closeDialog = function () {
                $mdDialog.hide();
            }
            questCtrl.openDialog = function (template) {
                var templates = {
                    "novaResposta": 'modules/instrutor/templates/novaResposta.html',
                    "novaQuestao": 'modules/instrutor/templates/novaQuestao.html'
                }
                return $mdDialog.show({
                    controller: ["copiaScope", function (copiaScope) {
                        return copiaScope;
                    }],
                    controllerAs: 'questCtrl',
                    locals: {
                        copiaScope: questCtrl
                    },
                    templateUrl: templates[template],
                    clickOutsideToClose: true
                }).then(function (modalResult) {
                    questCtrl.nvaInit();
                }).catch(function (modalError) {
                    questCtrl.nvaInit();
                });
            }   
            questCtrl.editQuestoes = function(){
                questCtrl.openDialog('novaQuestao');
                questCtrl.modoEdicao = true;
                questCtrl.nva = questoesService.normalizacaoFrontQst(questCtrl.qstSelecionada);
                questCtrl.respostaPadrao.ordem = (questCtrl.nva.respostas.length);
                console.log('questCtrl.qstSelecionada', questCtrl.qstSelecionada);
            }
            questCtrl.saveQuestoes = function(){
                questCtrl.progress = true;
                var questoes = questoesService.saveQuestoes(questCtrl.nva);
                questoes.then(function (questoesResult) {
                    questCtrl.progress = false;
                    questCtrl.closeDialog();
                    questCtrl.init();
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                });
            }
            questCtrl.atualizaQuestoes = function(){
                questCtrl.progress = true;
                var questoes = questoesService.atualizaQuestoes(questCtrl.nva);
                questoes.then(function (questoesResult) {
                    questCtrl.progress = false;
                    questCtrl.closeDialog();
                    questCtrl.init();
                    // console.log('questoesResult', questoesResult);
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                });
            }
            questCtrl.removerNvaResp = function(index){
                questCtrl.nva.respostas.splice(index,1);
            }

            questCtrl.deleteQuestoes = function(){
                $rootScope.showLoading = true;
                var questoes = questoesService.deleteQuestoes(questCtrl.qstSelecionada);
                questoes.then(function (questoesResult) {
                    $rootScope.showLoading = false;
                    questCtrl.init();
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                    questCtrl.init();
                });
            }
            questCtrl.deleteResposta = function(resposta,index){
                $rootScope.showLoading = true;
                var questoes = questoesService.deleteResposta(resposta);
                questoes.then(function (questoesResult) {
                    $rootScope.showLoading = false;
                    questCtrl.respostas.splice(index,1)
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                    questCtrl.init();
                });
            }
    }]);;angular.module('instrutor')
    .service('questoesService',
    ["$q", "$http", "db", "session", "$timeout", "msgsService", function ($q, $http, db, session, $timeout, msgsService) {
            return {
                getQuestoes: function() {    
                    var questoesProm = $q.defer();
                    db.dbActions('listaQuestoes', {}, 'questoes_adm')
                        .then(function (questoesResult) {
                            questoesProm.resolve(questoesResult.questoes);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                saveQuestoes: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('saveQuestoes', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                atualizaQuestoes: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('atualizaQuestoes', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                deleteQuestoes: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('deleteQuestoes', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                deleteResposta: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('deleteResposta', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                normalizacaoFrontQst:function(questao){
                    var corretaPosition='0';
                    for (var i = 0; i < questao.respostas.length;i++){
                        questao.respostas[i].ordem = questao.respostas[i].ordem*1;
                        if (questao.respostas[i].correta=='1'){
                            corretaPosition = i;
                        }
                    }
                    questao.correta = corretaPosition;
                    questao.questao = { "desc": questao.desc, "id": questao.id, "tempo": questao.tempo*1};
                    return questao;
                }
            }
        }]
    );angular.module('instrutor')
    .service('instrutorAvaliacaoService',
        ["$q", "$http", "db", "session", "$timeout", "msgsService", function($q, $http, db, session, $timeout,msgsService) {
            return {
                getListaAvaliacao: function() {    
                    var listaAvaliacaoProm = $q.defer();
                    db.dbActions('listaAvaliacao', {}, 'avaliacoes_adm')
                        .then(function (avaliacaoListaResult) {
                            listaAvaliacaoProm.resolve(avaliacaoListaResult);
                        }).catch(function (avaliacoesError) {
                            console.log('gettreinamentos-error', avaliacoesError);
                            listaAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return listaAvaliacaoProm.promise;
                },
                getListaQuestoesAvaliacao: function(avaliacao) {    
                    var listaQuestoesAvaliacaoProm = $q.defer();
                    db.dbActions('listaQuestoesAvaliacao', { "idAvaliacao": avaliacao.id}, 'avaliacoes_adm')
                        .then(function (questoesAvaliacaoResult) {
                            listaQuestoesAvaliacaoProm.resolve(questoesAvaliacaoResult);
                        }).catch(function (questoesAvaliacaoError) {
                            console.log('gettreinamentos-error', questoesAvaliacaoError);
                            listaQuestoesAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return listaQuestoesAvaliacaoProm.promise;
                },
                getQuestoesData:function(){
                    var listaQuestoesProm = $q.defer();
                    db.dbActions('listaQuestoes', {}, 'avaliacoes_adm')
                        .then(function (questoesResult) {
                            listaQuestoesProm.resolve(questoesResult);
                        }).catch(function (questoesError) {
                            console.log('gettreinamentos-error', questoesError);
                            listaQuestoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return listaQuestoesProm.promise;
                },
                saveAvaliacao: function (avaliacaoQuestoes){
                    var saveAvaliacaoProm = $q.defer();
                    db.dbActions('saveAvaliacao', { "avaliacaoQuestoes": avaliacaoQuestoes}, 'avaliacoes_adm')
                        .then(function (saveAvaliacaoResult) {
                            saveAvaliacaoProm.resolve(saveAvaliacaoResult);
                        }).catch(function (saveAvaliacaoError) {
                            console.log('saveAvaliacaoError', saveAvaliacaoError);
                            saveAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return saveAvaliacaoProm.promise;
                },
                atualizaAvaliacao: function (avaliacaoQuestoes){
                    var atualizaAvaliacaoProm = $q.defer();
                    db.dbActions('atualizaAvaliacao', avaliacaoQuestoes, 'avaliacoes_adm')
                        .then(function (atualizaAvaliacaoResult) {
                            atualizaAvaliacaoProm.resolve(atualizaAvaliacaoResult);
                        }).catch(function (atualizaAvaliacaoError) {
                            console.log('atualizaAvaliacaoError', atualizaAvaliacaoError);
                            atualizaAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return atualizaAvaliacaoProm.promise;
                },
                deleteAvaliacao: function (questao){
                    var deleteAvaliacaoProm = $q.defer();
                    db.dbActions('deleteAvaliacao', { "id": questao}, 'avaliacoes_adm')
                        .then(function (deleteAvaliacaoResult) {
                            if(!deleteAvaliacaoResult.removido){
                                deleteAvaliacaoProm.reject(msgsService.getMsg('app', 3));                                
                            }else{
                                deleteAvaliacaoProm.resolve(deleteAvaliacaoResult);
                            }
                        }).catch(function (deleteAvaliacaoError) {
                            console.log('deleteAvaliacaoError', deleteAvaliacaoError);
                            deleteAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return deleteAvaliacaoProm.promise;
                },
                deleteQuestaoAvaliacao: function (avaliacaoQuestao){
                    var deleteQuestaoAvaliacaoProm = $q.defer();
                    db.dbActions('deleteQuestaoAvaliacao', avaliacaoQuestao, 'avaliacoes_adm')
                        .then(function (deleteQuestaoAvaliacaoResult) {
                            if(!deleteQuestaoAvaliacaoResult.removido){
                                deleteQuestaoAvaliacaoProm.reject(msgsService.getMsg('app', 3));                                
                            }else{
                                deleteQuestaoAvaliacaoProm.resolve(deleteQuestaoAvaliacaoResult);
                            }
                        }).catch(function (deleteQuestaoAvaliacaoError) {
                            console.log('deleteQuestaoAvaliacaoError', deleteQuestaoAvaliacaoError);
                            deleteQuestaoAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return deleteQuestaoAvaliacaoProm.promise;
                }
            }
        }]
    );angular.module('meusDados')
    .controller('meusDadosController',
        ["$scope", "meusDadosService", "dialogService", "session", "$mdDialog", "msgsService", "$state", function($scope, meusDadosService, dialogService, session, $mdDialog, msgsService, $state) {
            $scope.init = function() {
                var userData = JSON.parse(session.getData('authData'));
                $scope.userLogin = userData;
                $scope.login = $scope.userLogin.user;          
            }
                
            $scope.save = function(){
                $scope.progress = true;
                
                meusDadosService.save($scope.login).then(function(saveUsuarioResult) {                    
                    $scope.userLogin.user.email = $scope.login.email;
                    session.setData('authData', JSON.stringify($scope.userLogin));
                    $scope.progress = false;
                    $scope.dialogMsg("Deu certo!", saveUsuarioResult);
                }).catch(function(saveUsuarioError) {
                    $scope.progress = false;
                    $scope.dialogMsg("Problemas!", saveUsuarioError);
                });
            }  
            $scope.dialogMsg = function(title, moduleMsg) {
                var confirmeJson = {
                    "title": title,
                    "content": msgsService.getMsg(moduleMsg.module, moduleMsg.msg),
                    "buttonOk": "Ok"
                };
                dialogService.confirm(confirmeJson).then(function() {
                    $state.go("home", {}, { reload: true });
                }).catch(function() {
                    $scope.init();
                });
            }     
            $scope.saveDisable = function(login,primeiroEmail){
                if (login.email == primeiroEmail && login.senha == undefined){
                    return true;
                }else{
                    return (login.senha != '' ? (login.senha != login.rsenha ? true : false) : true);
                }
            }
        }]);;angular.module('meusDados')
    .service('meusDadosService', ["$q", "db", "session", function($q, db, session) {
        return {
            save: function(usuario) {
                var updateUserProm = $q.defer();
                // var usuario = JSON.parse(session.getData('authData'));
                var saveUser = db.dbActions('updateUserData', usuario, 'login');
                saveUser.then(function(updateUserResult) {
                    if (updateUserResult.success == undefined) {
                        updateUserProm.reject(updateUserResult.error);
                    } else {
                        updateUserProm.resolve(updateUserResult.success);
                    }
                }).catch(function(saveUserError) {
                    updateUserProm.reject(saveUserError);
                });
                return updateUserProm.promise;

            }
        }
    }]);angular.module('menu')
    .controller('menuController',
        ["$mdBottomSheet", "$scope", "$mdSidenav", "$state", "session", function ($mdBottomSheet,$scope, $mdSidenav, $state,  session) {
            $scope.init = function() {
                var login = JSON.parse(session.getData('authData'));
                $scope.user = login.user;
                $scope.showMenus = JSON.parse(session.getData('configs'));
            }
                
            $scope.items = [
                {name: 'Obrigatório',class: 'red-tag'},
                {name: 'Em aberto',class: 'blue-tag'},
                // {name: 'Em avaliação',class: 'yellow-tag'},
                {name: 'Inscrito',class: 'purple-tag'},
                {name: 'Concluido',class: 'green-tag'},
                {name: 'Não participou',class: 'grey-tag'},
            ];

            $scope.colorLabels = function(){
                $scope.showGridBottomSheet();
            }
            $scope.close = function(menuClose) {
                $mdSidenav(menuClose).close()
                    .then(function() {
                        // $log.debug("close LEFT is done");
                    }).catch(function(evt) {
                        // console.log(evt);
                    });
            }

            $scope.toogleSideNav = function(menuClose) {
                $mdSidenav(menuClose).toggle();
                setTimeout(function() {
                    $scope.$broadcast('reCalcViewDimensions');
                }, 1)
            }

            $scope.goto = function(state) {
                if (state == "exit") {
                    sessionStorage.clear()
                    $state.go("initial");
                }
                $state.go(state);
                $scope.close('left');
            }

            $scope.showGridBottomSheet = function () {
                $mdBottomSheet.show({
                    templateUrl: 'modules/menu/color-labels.html',
                    controller: 'menuController',
                    clickOutsideToClose: true
                }).then(function (result) {
                    // console.log('showGridBottomSheet-result', result);
                }).catch(function (error) {
                    // console.log('showGridBottomSheet-error', error);
                    // User clicked outside or hit escape
                });
            };

        }]
    );;angular.module('treinamento')
    .controller('treinamentoController',
    ["$timeout", "$scope", "dialogService", "$rootScope", "$stateParams", "$state", "treinamentoService", "dateService", "session", "avaliacaoService", "time", function ($timeout, $scope, dialogService, $rootScope,$stateParams, $state, treinamentoService, dateService, session, avaliacaoService, time) {
        $scope.init = function () {
            $scope.hasParam();            
            var colaborador = JSON.parse(session.getData('authData'));
            $scope.colaborador = colaborador.user;            
            $scope.initVars();
            $scope.habilitaAvaliacoes();
        }
    
        $scope.initVars = function(){
            $scope.certificadoCanvas = "";
            $scope.classTableRow = true;
            $scope.botaoResposta = [];
            $scope.perguntaLiberada = [];
            $scope.iniciarTeste = false;
            $scope.currentTimeOut = {};
            $scope.avaliacaoRespostas = [];
            $scope.showCertificado = false;
            $scope.showAvaliacao = false;
            $scope.showAvaliacaoReacao = false;
            $scope.opiniaoDisserta = {};
        }

        $scope.hasParam = function () {
            if ($stateParams.treinamento == undefined || $stateParams.treinamento == null) {
                $state.go('home');
            } else {
                $scope.treinamento = $stateParams.treinamento;
            }
        }
        // ####################################
        // FICHA TECNICA
        // ####################################
        $scope.candidatura = function (acao) {
            if (acao == 'cancelar') {
                var confirmeJson = {
                    "title": "Informação!",
                    "content": "Após a desistência deste treinamento "+ 
                               "somente o RH poderá reativa-lo, realmente deseja desistir?",
                    "buttonOk": "Sim",
                    "buttonCancel": "Não"
                };
            } else {
                var confirmeJson = {
                    "title": "Informação!",
                    "content": "Candidate-se somente se tiver realmente certeza do seu comparecimento!",
                    "buttonOk": "Candidatar",
                    "buttonCancel": "Desistir"
                };
            }
            dialogService.confirm(confirmeJson).then(function(){
                if (acao == 'cancelar') {
                    $scope.cancelaCandidatura();
                    // window.open('https://bandeiranteslogisticarh.milldesk.com', '_blank');
                } else {
                    $scope.cadastrarCandidatura();
                }
            }).catch(function () {
                console.log('error dialog');
            });
        }
        $scope.cancelaCandidatura = function(){
            var usuario = JSON.parse(session.getData('authData'));
            var candidatura = treinamentoService.cancelaCandidatura($scope.treinamento, usuario);
            candidatura.then(function (candidaturaResult) {
                console.log('candidaturaResult', candidaturaResult);
                $scope.candidatarBtn = true;
                $scope.desCandidatarBtn = true;
            }).catch(function (candidaturaError) {
                console.log('candidaturaError', candidaturaError);
            });
        }
        $scope.cadastrarCandidatura = function(){
            var usuario = JSON.parse(session.getData('authData'));
            var candidatura = treinamentoService.insereCandidatura($scope.treinamento, usuario);
            candidatura.then(function (candidaturaResult) {
                var confirmeJson = {"title": "Parabéns!!","content": candidaturaResult,"buttonOk": "Ok","buttonCancel":null};
                dialogService.confirm(confirmeJson);
                $scope.candidatarBtn = true;
                console.log('candidaturaResult', candidaturaResult);
            }).catch(function (candidaturaError) {
                var confirmeJson = { "title": "Problemas!", "content": candidaturaError,"buttonOk": "Ok","buttonCancel":null};
                dialogService.confirm(confirmeJson).then(function(){
                    location.reload();
                });
                console.log('candidaturaError', candidaturaError);
            });
        }
        // ####################################
        // CERTIFICADOS
        // ####################################
        $scope.dataCabecalho = function (data) {
            return dateService.formatDateHeader(data);
        }        
        $scope.generatePic = function () {
            $rootScope.showLoading = true;
            var certificadoDiv = document.querySelector("#certificado");
            kendo.drawing
                .drawDOM(certificadoDiv,
                    {
                        forcePageBreak: ".page-break",
                        paperSize: "A4",
                        scale: 1,
                        height: 595,
                        landscape: true
                    })
                .then(function (group) {
                    $rootScope.showLoading = false;
                    kendo.drawing.pdf.saveAs(group, "Certificado " + $scope.treinamento.nome + ".pdf");
                });
        }
        // ####################################
        // AVALIAÇÃO
        // ####################################
        $scope.getAvaliacao = function(){                            
            $scope.showAvaliacao = false;
            avaliacaoService.getAvaliacao($scope.treinamento)
                .then(function (getAvaliacaoResult) {  
                    if (getAvaliacaoResult.listaAvaliacao.length>0){
                        $scope.ativaAvaliacao(getAvaliacaoResult);
                    }
                }).catch(function (getAvaliacaoError) {
                    console.log("getAvaliacaoError", getAvaliacaoError);
                });
        }
        $scope.ativaAvaliacao = function(treinamento){
            var avRealizadas = treinamento.avaliacaoRealizada;
            var listaAv = treinamento.listaAvaliacao;
            if (avRealizadas.length>0){
                if (avRealizadas.length < listaAv.length){
                    for (var i = 0; i < avRealizadas.length; i++) {
                        for (var x = 0; x < listaAv.length; x++) {
                            if (avRealizadas[i].fk_avaliacao_prova == listaAv[x].idProva) {
                                if ((avRealizadas[i].aproveitamento * 1) >= listaAv[x].minimo) { 
                                    $scope.avaliacao = listaAv[x];
                                    $scope.openCertificado();
                                    break;
                                } else {
                                    // console.log(avRealizadas, x);
                                    if (x < (listaAv.length-1)){
                                        $scope.avaliacao = treinamento.listaAvaliacao[x+1];
                                        $scope.avaliacao.resultado = {};                                     
                                        $scope.showAvaliacao = true;
                                        $scope.getInfoAvaliacao($scope.avaliacao);
                                    }
                                }
                            }
                        }
                    }
                }else{
                    $scope.avaliacao = listaAv[(listaAv.length-1)];
                    var ultimaAvaliacao = avRealizadas[(avRealizadas.length-1)];
                    $scope.avaliacao.resultado = {};
                    $scope.avaliacao.resultado.aprovado = ultimaAvaliacao.aprovado=="1"?true:false;
                    $scope.avaliacao.resultado.aproveitamento = ultimaAvaliacao.aproveitamento;
                    $scope.openCertificado();
                }
            }else{
                if (!$scope.showAvaliacaoReacao){
                    $scope.avaliacao = treinamento.listaAvaliacao[0];     
                    $scope.avaliacao.resultado = {};                                                                
                    $scope.showAvaliacao = true;
                    // $scope.selectedTab = 2;
                    $rootScope.showLoading = false;                    
                    $scope.getInfoAvaliacao($scope.avaliacao);
                }
            }
        }
        $scope.getInfoAvaliacao = function(avaliacao){            
            var tempoMaximo = 0;
            for (var i = 0; i < avaliacao.perguntas.length;i++){
                tempoMaximo += avaliacao.perguntas[i].tempo;
            }
            var tempoMedio = time.secondsToStringMin(tempoMaximo / avaliacao.perguntas.length);
            tempoMaximo = time.secondsToStringMin(tempoMaximo);
            $scope.infoTreinamento = {
                "qtdQuestoes": avaliacao.perguntas.length,
                "tempoMaximo": tempoMaximo.minutes + "m" + tempoMaximo.seconds+"s",
                "tempoMedio": tempoMedio.minutes + "m" + tempoMedio.seconds + "s"
            };            
        }
        $scope.enviarResposta = function(pergunta,resposta,id){
            if (resposta && $scope.botaoResposta[id]=='blue-btn'){
                $timeout.cancel($scope.currentTimeOut);                    
                $scope.botaoResposta[id] = 'loading';
                $timeout(function(){
                    pergunta.resultado = pergunta.correta == resposta[id]?1:0;
                    $scope.botaoResposta[id] = 'green-btn'; 
                    $timeout(function () {
                        id++;
                        $scope.startCount(id);
                        $scope.perguntaLiberada[id] = true;
                        $scope.perguntaLiberada[(id - 1)] = false;     
                    },2000);                                               
                },500);
            }
        }
        $scope.startTest = function(){
            $scope.perguntaLiberada[0] = true;
            $timeout(function () {
                $scope.startCount(0);
            }, 700)
        }
        $scope.startCount = function(id){    
            var qtdPerguntas = $scope.avaliacao.perguntas.length;
            if (id < qtdPerguntas) {                      
                if ($scope.avaliacao.perguntas[id].tempo>0){
                    $scope.currentTimeOut = 
                    $timeout(function(){
                        $scope.avaliacao.perguntas[id].tempo--;
                        $scope.startCount(id);
                    },1000);
                }else{                    
                    $scope.currentTimeOut = 
                    $timeout(function () {
                        $scope.enviarResposta(
                            $scope.avaliacao.perguntas[id], 
                            $scope.avaliacaoRespostas,
                            id
                        );
                    }, 500);
                }
            }else{
                var calcResultado = avaliacaoService.calculaResultado($scope.avaliacao);
                var saveAvaliacao = avaliacaoService.saveResultado(calcResultado);
                saveAvaliacao.then(function (avaliacaoSaveResult) { 
                    console.log('avaliacaoSaveResult', avaliacaoSaveResult);
                    $scope.avaliacao.resultado.aprovado = calcResultado.resultado.aprovado;
                    $scope.avaliacao.resultado.aproveitamento = calcResultado.resultado.aproveitamento;
                }).catch(function (avaliacaoSaveError) { 
                    console.log('avaliacaoSaveError', avaliacaoSaveError);
                });                
            }   
        }
        $scope.openCertificado = function(){
            $scope.showCertificado = true;
            $scope.showAvaliacao = false;
            $scope.showAvaliacaoReacao = false;
        }
        // ####################################
        // AVALIAÇÃO REAÇÃO
        // ####################################
        $scope.saveAr = function(){
            $scope.loadingSaveAr = true;
            var saveArData = {
                "opiniaoDisserta": $scope.opiniaoDisserta,
                "perguntasAr": $scope.treinamento.perguntasAR,
                "treinamento": $scope.treinamento,
                "usuario": $scope.colaborador
            };            
            avaliacaoService.saveQuestoesAR(saveArData)
                .then(function (savearResult) {
                    console.log('savearResult', savearResult);
                    $scope.loadingSaveAr = false;
                    var confirmeJson = { "title": "Parabéns!", "content": savearResult, "buttonOk": "Ok", "buttonCancel": undefined };
                    dialogService.confirm(confirmeJson).then(function () {
                        $scope.showAvaliacaoReacao = false;                                                                
                        // Retornar somente após apresentação
                        $scope.openCertificado();
                        // $scope.getAvaliacao();
                    });
                }).catch(function (savearError) {
                    console.log('savearError', savearError);
                    var confirmeJson = { "title": "Problemas!", "content": savearError, "buttonOk": "Ok", "buttonCancel": undefined };
                    dialogService.confirm(confirmeJson).then(function () {                            
                    });
                });                
        }

        $scope.habilitaAvaliacoes = function(){
            $rootScope.showLoading = true;
            var avaliacoesLiberadas = treinamentoService.acessoAvaliacoes($scope.treinamento, $scope.colaborador);
            avaliacoesLiberadas.then(function (liberadasResult) {
                console.log('liberadasResult', liberadasResult);
                var dataTreinamento = treinamentoService.treinamentoValidaData($scope.treinamento,3);
                $scope.candidatarBtn = treinamentoService.candidaturaHabilitada($scope.treinamento);
                $scope.desCandidatarBtn = (liberadasResult.candidatado.length > 0 ? false : true) || dataTreinamento;
                $rootScope.showLoading = false;
                if (liberadasResult.liberada){
                    $scope.getAvaliacaoReacao();
                }
            }).catch(function (liberadasResultError) { 
                console.log('liberadasResultError', liberadasResultError);
            })
        }
        $scope.getAvaliacaoReacao = function () {
            $rootScope.showLoading = true;   
            var dadosGetQuestoesAR = {"treinamento": $scope.treinamento,"usuario": $scope.colaborador}   ;
            avaliacaoService.getQuestoesAR(dadosGetQuestoesAR).then(function (result) {
                    $rootScope.showLoading = false;                    
                    $scope.treinamento.perguntasAR = result.avaliacaoReacao;
                    $scope.showAvaliacaoReacao = !result.respondido;
                    
                    // Retornar somente após apresentação
                    if(result.respondido){
                        $scope.openCertificado();
                    }
                    // $scope.getAvaliacao();
                }).catch(function (error) {
                    var confirmeJson = { "title": "Problemas!", "content": error, "buttonOk": "Ok", "buttonCancel": undefined };
                    dialogService.confirm(confirmeJson);
                });
        }

    }]
);;angular.module('treinamento')
    .service('treinamentoService', 
        ["$q", "$http", "db", "session", "time", "msgsService", function ($q, $http, db, session, time, msgsService) {
            return {                
                candidaturaHabilitada:function(treinamento){
                    var habilitada = false;
                    var validacoes = ["treinamentoValidaData","lotacaoTreinamento"];
                    for (var i = 0; i < validacoes.length;i++){                        
                        switch (validacoes[i]){
                            case 'treinamentoValidaData':
                                habilitada = this.treinamentoValidaData(treinamento,3);
                            break;
                            case 'lotacaoTreinamento':
                                habilitada = this.lotacaoTreinamento(treinamento);
                            break;
                            default:
                                console.log('default',treinamento);
                        }
                        if(habilitada){
                            break;
                        }
                    }
                    return habilitada;
                },
                treinamentoValidaData:function(treinamento,addDays){
                    var habilitada = false;                    
                    if (treinamento.data != null) {
                        // Só pode se candidatar no prazo de 3 dias
                        var today = new Date();
                        today.setDate(today.getDate() + addDays);

                        var dtT = treinamento.data.split('-');
                        var passouData = new Date(dtT[0], (dtT[1] - 1), dtT[2]) - today;
                        habilitada = passouData > 0 ? false : true;
                    }
                    return habilitada;
                },
                lotacaoTreinamento: function (treinamento){
                    var habilitada = false;  
                    if (treinamento.data != null) {
                        habilitada = treinamento.lotacao - treinamento.colaboradores.length <= 0 ? true : false;
                    }
                    return habilitada;
                },
                acessoAvaliacoes: function (treinamento,usuario){
                    var acessaAvalProm = $q.defer();
                    var liberado = this.treinamentoValidaData(treinamento,0);
                    // if(liberado){
                        this.usuarioCandidatado(treinamento, usuario).then(function (candidatadoResult) { 
                            var avaliacaoLiberada = (candidatadoResult.length > 0 && liberado)?true:false;
                            var resolveResult = { "liberada": avaliacaoLiberada, "candidatado": candidatadoResult };
                            acessaAvalProm.resolve(resolveResult);
                        }).catch(function (candidatadoError) { 
                            console.log('candidatadoError', candidatadoError, liberado);
                        });
                    // }else{
                    //     acessaAvalProm.resolve({ "liberada": liberado, "candidatado": [] });
                    // }
                    return acessaAvalProm.promise;
                },
                usuarioCandidatado: function (treinamento, usuario){
                    var candidatadoProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": 'consultaCandidatoTreinamento', "treinamento": treinamento, "usuario": usuario }, 'treinamento-vetorh')
                        .then(function (candidaturaResult) {
                            candidatadoProm.resolve(candidaturaResult.candidatura);
                        }).catch(function (candidaturaError) {
                            console.log('candidaturaError', candidaturaError);
                            candidatadoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return candidatadoProm.promise;
                },
                insereCandidatura:function(treinamento,usuario){
                    var candidaturaProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": 'insereCandidato', "treinamento": treinamento, "usuario": usuario }, 'treinamento-vetorh')
                        .then(function (candidaturaResult) {
                            if (candidaturaResult.candidatura){
                                candidaturaProm.resolve(msgsService.getMsg('treinamentos', 1));
                            }else{
                                candidaturaProm.reject(msgsService.getMsg('treinamentos', 2));
                            }                            
                        }).catch(function (candidaturaError) {
                            console.log('candidaturaError', candidaturaError);
                            candidaturaProm.reject(msgsService.getMsg('app', 3));
                        });
                    return candidaturaProm.promise;
                },
                cancelaCandidatura:function(treinamento,usuario){
                    var candidaturaProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": 'cancelaCandidato', "treinamento": treinamento, "usuario": usuario }, 'treinamento-vetorh')
                        .then(function (candidaturaResult) {
                            console.log('candidaturaResult', candidaturaResult);
                            candidaturaProm.resolve(candidaturaResult);
                        }).catch(function (candidaturaError) {
                            console.log('candidaturaError', candidaturaError);
                            candidaturaProm.reject(msgsService.getMsg('app', 3));
                        });
                    return candidaturaProm.promise;
                }
            }
        }]
    );angular.module('treinamento')
    .service('avaliacaoService', 
    ["$q", "$http", "db", "session", "time", "msgsService", function ($q, $http, db, session, time, msgsService) {
            return {
                saveQuestoesAR: function (respostas) {
                    var avaliacaoReacaoProm = $q.defer();
                    db.dbActions('saveQuestoesAR', respostas, 'avaliacoesReacao')
                        .then(function (avaliacaoReacaoResult) {
                            console.log('avaliacaoReacaoResult', avaliacaoReacaoResult);
                            if (avaliacaoReacaoResult.enviado) {
                                avaliacaoReacaoProm.resolve(msgsService.getMsg('avaliacao-reacao', 1));
                            } else {
                                avaliacaoReacaoProm.reject(msgsService.getMsg('avaliacao-reacao', 2));
                            }
                        }).catch(function (avaliacaoReacaoError) {
                            console.log('avaliacaoReacaoError', avaliacaoReacaoError);
                            avaliacaoReacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return avaliacaoReacaoProm.promise;
                },
                getQuestoesAR: function (treinamento) {
                    var avaliacaoReacaoProm = $q.defer();
                    db.dbActions('lista', treinamento, 'avaliacoesReacao')
                        .then(function (avaliacaoReacaoResult) {
                            avaliacaoReacaoProm.resolve(avaliacaoReacaoResult);
                        }).catch(function (avaliacaoReacaoError) {
                            console.log('lista-avaliacoes-error', avaliacaoReacaoError);
                            avaliacaoReacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return avaliacaoReacaoProm.promise;
                },
                getAvaliacao:function(treinamento){
                    var avaliacaoProm = $q.defer();
                    treinamento.usuario = JSON.parse(session.getData('authData'));
                    db.dbActions('getAvaliacao', treinamento, 'avaliacoes')
                        .then(function (avaliacaoResult) {
                            avaliacaoProm.resolve(avaliacaoResult);
                        }).catch(function (avaliacaoError) {
                            console.log('getAvaliacao-error', avaliacaoError);
                            avaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return avaliacaoProm.promise;
                },
                calculaResultado: function (treinamento) {
                    var qtdPerguntas = treinamento.perguntas.length;
                    var corretas = 0;
                    for (var i = 0; i < qtdPerguntas; i++) {
                        corretas = corretas + treinamento.perguntas[i].resultado
                    }
                    var media = (corretas * 100) / qtdPerguntas;
                    treinamento.resultado.aprovado = media >= treinamento.minimo?true:false;
                    treinamento.resultado.aproveitamento = media;
                    return treinamento;
                },
                saveResultado: function (treinamento){
                    var avaliacaoProm = $q.defer();
                    treinamento.usuario = JSON.parse(session.getData('authData'));
                    db.dbActions('saveAvaliacao', treinamento, 'avaliacoes')
                        .then(function (avaliacaoResult) {
                            console.log('avaliacaoResult', avaliacaoResult);
                            avaliacaoProm.resolve(avaliacaoResult.avaliacao);
                        }).catch(function (avaliacaoError) {
                            console.log('getAvaliacao-error', avaliacaoError);
                            avaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return avaliacaoProm.promise;
                }
            }
        }]
    );angular.module('dbServer')
    .service('db', ['$q', '$http', 'appUrls', 'errorRequestService',
        function($q, $http, appUrls, errorRequestService) {
            return {
                dbActions: function(acao, param, modulo, timeoutSelected) {
                    var data = {
                        'acao': acao,
                        'param': param,
                        'modulo': modulo
                    };
                    var timeoutToRequest = 30000;

                    if (timeoutSelected != undefined || timeoutSelected != null) {
                        timeoutToRequest = timeoutSelected;
                    }
                    var requestConfig = {
                        url: appUrls.getUrl("app"),
                        data: data,
                        method: 'post',
                        timeout: timeoutToRequest
                    }

                    var prom = $q.defer();

                    $http(requestConfig).then(function(response) {
                        responseData = response.data;
                        if (responseData != undefined) {
                            if (responseData.length < 1) {
                                prom.reject("sem dados");
                            } else {
                                prom.resolve(responseData);
                            }
                        } else {
                            prom.reject("sem dados");
                        }
                    }, function(response) {
                        console.log('db-error', response);
                        prom.reject(errorRequestService.getMsg(response.status));
                    });
                    return prom.promise;
                }
            }
        }
    ]);angular.module('bandTrainingCalendar')
    .service('appUrls', [function() {
        return {
            getEnv: function() {
                var environments = {
                    "localhost": "dev",
                    "dev": "dev",
                    "web": "web"
                };
                var httpHost = window.location.hostname;
                var firstNameHost = httpHost.split('.');
                return environments[firstNameHost[0]];
            },
            getUrl: function(url) {
                var urlMaps = {
                    "dev": {
                        "app": "http://dev.new.band/treinamentos/services/v1/"
                    },
                    "web": {
                        "app": "http://web.new.band/treinamentos/services/v1/"
                    }
                };
                return urlMaps[this.getEnv()][url];
            }
        }
    }]);angular.module('bandTrainingCalendar')
    .service('dialogService', ['$mdDialog', '$rootScope', '$q',
        function($mdDialog, $rootScope, $q) {
            // msgsService
            return {
                alert: function(msg) {
                    $mdDialog.show(
                        $mdDialog.alert()
                        // .parent(angular.element(document.querySelector('#popupContainer')))
                        .clickOutsideToClose(true)
                        .title('Mensagem')
                        .textContent(msg)
                        // .ariaLabel('Alert Dialog Demo')
                        .ok('Ok')
                        // .targetEvent(alert('asdasd'))
                    );
                },
                confirm: function(confirmeJson) {
                    // var confirmeJson = {
                    //     "title": "Algo aconteceu!",
                    //     "content": validacaoErro.msgRetorno,
                    //     "buttonOk": "Ok",
                    // 	   "buttonCancel":"Cancel"
                    // };				
                    var confirmProm = $q.defer();
                    var confirm;

                    if (confirmeJson.buttonCancel != undefined) {
                        confirm = $mdDialog.confirm();
                        confirm.cancel(confirmeJson.buttonCancel);
                    } else {
                        confirm = $mdDialog.alert();
                    }

                    confirm.title(confirmeJson.title)
                        .textContent(confirmeJson.content)
                        .ariaLabel(confirmeJson.label)
                        .ok(confirmeJson.buttonOk);

                    $mdDialog.show(confirm).then(function() {
                        confirmProm.resolve(true);
                    }, function() {
                        confirmProm.reject(false);
                    });

                    return confirmProm.promise;
                },
                loading: function(paramLoading) {

                    if (paramLoading == 'hide') {
                        $mdDialog.hide();
                        return;
                    }

                    // var msg = msgsService.getMsg('app', '4');

                    $mdDialog.show({
                        template: '<div id="loading">' +
                            '<div class="contain-animation">' +
                            '<div class="contain-bear">' +
                            '<img class="prints" src="img/loading/pawprints.svg" alt="Bear Prints" />' +
                            '<span class="cover"></span>' +
                            '</div>' +
                            '</div>' +
                            '</div>',
                        parent: angular.element(document.body),
                        clickOutsideToClose: false,
                        fullscreen: false,
                        escapeToClose: false
                    });


                },
                openNewWindow: function(url) {
                    window.open(url, '_blank', 'location=yes,scrollbars=yes,status=yes')
                }
            }
        }
    ]);angular.module('bandTrainingCalendar')
    .service('errorRequestService', ['msgsService',
        function(msgsService) {
            return {
                getMsg: function(status) {
                    switch (status) {
                        case 408:
                            return msgsService.getMsg('app', '2');
                        default:
                            return msgsService.getMsg('app', '3');
                    }
                }
            }
        }
    ]);angular.module('bandTrainingCalendar')
    .service('msgsService', [function() {
        return {
            getIdioma: function() {
                var idioma = sessionStorage.getItem('idioma');
                if (idioma == undefined || idioma == null) {
                    idioma = "portugues";
                }
                return idioma;
            },
            getMsg: function(modulo, idMsg) {
                var idioma = this.getIdioma();
                var msgs = {
                    "portugues": {
                        "usuario": {
                            "1": "Usuário ou senha incorretos, por favor tente novamente!",
                            "2": "Usuário já cadastrado!",
                            "3": "Usuário removido!",
                            "4": "Usuário não possui acesso!",
                            "5": "Usuário ainda não está cadastrado, realize seu cadastro!",
                            "6": "Token invalido, por favor solicite uma nova recuperação de senha!"
                        },
                        "app": {
                            "1": "Dados salvos com sucesso!",
                            "2": "Problemas de conexão com a internet. Por favor, tente novamente mais tarde!",
                            "3": "Ocorreu um erro inesperado. Por favor, tente novamente ou contate nosso suporte!",
                            "4": "Por favor, aguarde...",
                            "5": "Dados de sessão corrompidos. Por favor, faça o login novamente!",
                            "6": "Preencha todos os campos corretamente!",
                            "7": "Tipo de arquivo inválido!",
                            "8": "Não foram encontrados dados para os filtros selecionados!",
                            "10": "Nenhum dado encontrado!",
                            "11": "E-mail enviado com sucesso!"
                        },
                        "avaliacao-reacao":{
                            "1": "Obrigado por contribuir com sua opinião. A partir de agora você já está habilitado a fazer a avaliação!",
                            "2": "Você já envio suas opinões para esse treinamento!"
                        },
                        "treinamentos":{
                            "1":"Candidatura realizada com sucesso!",
                            "2":"Não existem mais vagas para essa turma, tente outra turma!"
                        }
                    },
                    "ingles": {
                        "usuario": {
                            "1": "Incorrect CPF or password, please try again!"
                        },
                        "app": {
                            "1": "Data saved successfully!",
                            "2": "Problems connecting to the internet. Please try again later!",
                            "3": "An unexpected error has occurred. Please try again or contact our support!",
                            "4": "Please wait...",
                            "5": "Session data corrupted. Please, login again!",
                            "6": "Complete all the fields correctly!",
                            "7": "Invalid file type!",
                            "8": "No data was found for the selected filters!",
                            "10": "No data found, please try again later!"
                        }
                    },
                    "espanhol": {
                        "usuario": {
                            "1": "CPF o contraseña incorrecta, por favor inténtelo de nuevo!"
                        },
                        "app": {
                            "1": "Datos guardados con éxito!",
                            "2": "Problemas de conexión a Internet. Por favor, inténtelo de nuevo más tarde!",
                            "3": "Se ha producido un error inesperado. Por favor, inténtelo de nuevo o contacte nuestro soporte!",
                            "4": "Por favor, espere ...",
                            "5": "Datos de sesión dañados. Por favor, inicie sesión de nuevo!",
                            "6": "Rellena todos los campos correctamente!",
                            "7": "Tipo de archivo no válido!",
                            "8": "No se han asignado datos a los filtros seleccionados!",
                            "10": "Ningún dato encontrado, vuelva a intentarlo más tarde!"
                        }
                    }
                };
                return msgs[idioma][modulo][idMsg];
            }
        }
    }]);angular.module('mapsService')
    .service('maps', ['$q',
        function($q) {
            return {
                getCurrentLocation: function() {
                    var locationProm = $q.defer();
                    var location = {};
                    if (!navigator.geolocation) {
                        location.error = 'Navegador não suporta localização!';
                        locationProm.reject(location);
                    }

                    navigator.geolocation.getCurrentPosition(function(position) {
                        location.lat = position.coords.latitude;
                        location.lng = position.coords.longitude;
                        locationProm.resolve(location);
                    }, function(error) {
                        location.error = 'Problemas na hora de pegar localização!';
                        locationProm.reject(location);
                    });

                    return locationProm.promise;
                }
            }
        }
    ]);angular.module('bandTrainingCalendar')
    .service('session', ['msgsService', '$state', 'dialogService',
        function(msgsService, $state, dialogService) {
            return {
                setData: function(nameData, data) {
                    try {
                        sessionStorage.removeItem(nameData);
                        sessionStorage.setItem(nameData, btoa(data));
                        return true;
                    } catch (error) {
                        throw error;
                    }
                },
                getData: function(nameData) {
                    try {
                        if (!sessionStorage.getItem(nameData)) {
                            throw msgsService.getMsg('app', '5');
                        }

                        return atob(sessionStorage.getItem(nameData));
                    } catch (error) {
                        throw msgsService.getMsg('app', '5');
                    }
                },
                valideSession: function(state) {
                    try {
                        if (!sessionStorage.getItem('authData')) {
                            this.brokedSession();
                            return false;
                        }else{
                            var acessos = JSON.parse(this.getData('configs'));
                            var acessa = false;
                            for (var i = 0; i < acessos.length;i++){
                                if (acessos[i].state==state){
                                    acessa = true;                                    
                                }
                            }
                            if(!acessa){
                                $state.go('home');                                                                                        
                            }
                            return acessa;
                        }
                        return true;
                    } catch (error) {
                        msgsService.getMsg('app', '5');
                    }
                },
                clear: function() {
                    sessionStorage.clear();
                },
                brokedSession: function(){
                    dialogService.alert(msgsService.getMsg('app', '5'));
                    sessionStorage.clear();
                    $state.go('initial');   
                }
            }
        }
    ]);angular.module('timeService')
    .service('time', [function () {
        return {
            StringToNumber: function (timeString) {
                var horas = timeString.split(':');
                var segundos = (horas[2] == undefined) ? null : horas[2] * 1;
                return { "horas": horas[0] * 1, "minutos": horas[1] * 1, "segundos": segundos };
            },
            numberToString: function (timeObject) {
                timeObject.horas = timeObject.horas * 1;
                var horas = "" + timeObject.horas;
                horas = horas.length == 1 ? "0" + horas : horas;

                timeObject.minutos = timeObject.minutos * 1;
                var minutos = "" + timeObject.minutos;
                minutos = minutos.length == 1 ? "0" + minutos : minutos;

                var segundos = (timeObject.segundos == undefined || timeObject.segundos == null) ? "" : timeObject.segundos;
                segundos = "" + (segundos.length < 1 ? "" : segundos * 1);
                segundos = segundos.length == 1 ? "0" + segundos : segundos;
                segundos = segundos.length > 1 ? ":" + segundos : "";

                return horas + ":" + minutos + segundos;
            },
            formatCalcDatesResult: function (resultCalc) {
                var secondsFromCalc = parseInt((resultCalc * 60) * 60, 10);
                var hours = Math.floor(secondsFromCalc / 3600);
                var minutes = Math.floor((secondsFromCalc - (hours * 3600)) / 60);
                var seconds = secondsFromCalc - (hours * 3600) - (minutes * 60);
                // hours = hours < 10 ? "0" + hours : hours;
                // minutes = minutes < 10 ? "0" + minutes : minutes;
                // seconds = seconds < 10 ? "0" + seconds : seconds;
                if (hours < 10) { hours = "0" + hours; }
                if (minutes < 10) { minutes = "0" + minutes; }
                if (seconds < 10) { seconds = "0" + seconds; }

                return hours + ':' + minutes + ':' + seconds;
            },
            newDateToIe: function (date) {
                // hack necessário para corrigir falha no internet explorer em interpretação de datas

                var date = date.split('-');
                var dates = date[2].split(' ');
                var hours = dates[1].split(':');

                date[0] = Math.floor(("" + date[0]).replace(/[^0-9]/gi, ""));
                date[1] = Math.floor(("" + date[1]).replace(/[^0-9]/gi, "")) - 1;
                dates[0] = Math.floor(("" + dates[0]).replace(/[^0-9]/gi, ""));
                hours[0] = Math.floor(("" + hours[0]).replace(/[^0-9]/gi, ""));
                hours[1] = Math.floor(("" + hours[1]).replace(/[^0-9]/gi, ""));
                var arrayDate = [date[0], date[1], dates[0], hours[0], hours[1], 0];
                return arrayDate;
            },
            secondsToStringMin:function(secondsToConvert){
                var minutes = Math.floor(secondsToConvert / 60);
                var seconds = Math.floor(secondsToConvert - (minutes * 60));
                minutes = minutes.toString().length<=1?'0'+minutes:minutes;
                seconds = seconds.toString().length <= 1 ? '0' + seconds : seconds;                
                return { "minutes": minutes,"seconds":seconds};
            }
        }
    }]);angular.module('bandTrainingCalendar')
    .service('auth', ["session", "$q", "$http", "$state", "appUrls", "msgsService", function (session, $q, $http, $state, appUrls, msgsService) {
        return {
            login: function(user) {
                var authProm = $q.defer();
                $http.post(appUrls.getUrl('app'), user)
                    .then(function(authResult) {
                        // console.log(authResult.data);
                        var auth = authResult.data;
                        if (auth.validPass && auth.userRH!=null){
                            authProm.resolve(auth);
                            session.setData('authData', JSON.stringify(auth));
                            session.setData('configs', JSON.stringify(auth.user.configs));
                        }else{
                            if (!auth.userExist && !auth.validPass && auth.userRH == null){
                                auth.msgError = msgsService.getMsg('usuario', 4);
                                authProm.reject(auth);
                            } else if (auth.userExist && !auth.validPass){                                
                                auth.msgError = msgsService.getMsg('usuario', 1);
                                authProm.reject(auth);
                            } else if (!auth.userExist && !auth.validPass && auth.userRH != null){
                                auth.msgError = msgsService.getMsg('usuario', 5);
                                authProm.resolve(auth);                            
                            } else if (auth.userExist && auth.validPass && auth.userRH == null) {
                                auth.msgError = msgsService.getMsg('usuario', 4);
                                authProm.reject(auth);
                            }else{
                                auth.msgError = msgsService.getMsg('usuario', 3);
                                authProm.reject(auth);
                            }
                        }
                    }).catch(function(authError) {
                        console.log('authError', authError);
                        authProm.reject(authResult);
                    });
                return authProm.promise;
            },
            logout: function() {
                session.clear();
                $state.go('initial');
            }
        }
    }]);angular.module('bandTrainingCalendar')
    .service('dateService', [function() {
        return {
            formatDateDB: function(date) {

                var optionsDate = { year: 'numeric', month: 'numeric', day: 'numeric' };
                var resultFinal = date.toLocaleDateString('pt-BR', optionsDate)
                    .replace('BRT', '')
                    .trim().split('/').reverse().join('-')
                return resultFinal;

            },
            formatDateTimeDB: function(date) {

                var optionsDate = { timeZone: 'America/Sao_Paulo', year: 'numeric', month: 'numeric', day: 'numeric' };
                var optionsTime = { timeZone: 'America/Sao_Paulo', hour: 'numeric', minute: 'numeric', second: 'numeric' };

                var dtStr = date.toLocaleDateString('pt-BR', optionsDate)
                    .replace('BRT', '')
                    .trim().split('/').reverse().join('-');


                var timeStr = date.toLocaleTimeString('pt-BR', optionsTime).replace('BRT', '').trim();

                return dtStr + ' ' + timeStr;
            },
            formatDateHeader: function(date){
                var toGetMonth = new Date(date);
                var month = toGetMonth.toLocaleString("pt-br", { month: "long" });
                var arrayDate = date.split('-');                
                return arrayDate[2] + ' de ' + month + ' de ' + arrayDate[0];
            }
        }
    }]);angular.module('text')
    .directive('reduceDesc', function () {
        return function (scope, elm, attr) {
            //console.log(scope, elm, attr);                
        };
    }).directive('numbers', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    });;angular.module('bandTrainingCalendar')
    .filter('capitalize', [function() {
        return function(input) {
            return (!!input) ? input.charAt(0).toUpperCase() + input.substr(1).toLowerCase() : '';
        }
    }]);