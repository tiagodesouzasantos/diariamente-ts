var treinamentosFake = {
    "2018-07-22": [
        {
            "nome": "NR35",
            "id": "1",            
            "lotacao":"50",
            "pontuacao":"15",
            "desc": "A NR 35 é a Norma Regulamentadora que estabelece os requisitos mínimos e as medidas de proteção para o trabalho em altura, envolvendo o planejamento, a organização e a execução, de forma a garantir a segurança e a saúde dos trabalhadores envolvidos direta ou indiretamente com esta atividade.",
            "horario": { "inicio": "08:00", "fim": "12:00" },
            "conteudoProgramatico": ["O que são Aspectos Ambientais", "O que são impactos Ambientais", "O que é Perigo; O que é risco", "Exposição", "Planilha de Aspectos e Impactos & Perigos e Riscos","Objetivo: Orientar o participante dos perigos e riscos de sua localidade (área)"],
            "data":"2018-07-22",
            "termina":"2018-07-23",
            "cargaHoraria": "1 hora",
            "instrutor": {                
                "id":2,
                "nome": "Jiraylson jiban da silva",
                "desc": "Doutor especializado em ministrar treinamentos de NR35.",
            },
            "endereco": "Rua Visconde do rio branco n², 1ºAndar",
            "local": "Corporativo I",
            "colaboradores": [
                { "nome": "Talles", "setor": "TI", "local": "Corporativo" },
                { "nome": "Caio", "setor": "Coletor", "local": "IPA" },
                { "nome": "Fernando A.", "setor": "DTA", "local": "IPA" },
                { "nome": "Renan Ska", "setor": "TI", "local": "Corp. II" },
                { "id": 1, "matricula": "601200", "nome": "Caio", "setor": "Coletor", "local": "IPA" },
                { "nome": "Luan", "setor": "Cont.", "local": "CLIA" },
                { "nome": "Band", "setor": "Portuario", "local": "Santos/SP" },
                { "nome": "Dia%", "setor": "Varejo M.", "local": "São Paulo" },
                { "id": 1, "matricula": "601215","nome": "Tiago", "setor": "Portuario", "local": "Santos/SP" },                
                { "nome": "DeicMar", "setor": "Portuario", "local": "Santos/SP" },
                { "nome": "Meio", "setor": "Portuario", "local": "SV" },
                { "nome": "Ultimo", "setor": "Portuario", "local": "Santos/SP" },
            ]
        },
        {
            "nome": "NR55",
            "id": "7",        
            "lotacao": "1",                
            "pontuacao":"15",
            "desc": "Norma para trabalhos em altura",
            "horario": { "inicio": "13:00", "fim": "14:45" },
            "conteudoProgramatico": ["O que são Aspectos Ambientais", "O que são impactos Ambientais", "O que é Perigo; O que é risco", "Exposição", "Planilha de Aspectos e Impactos & Perigos e Riscos", "Objetivo: Orientar o participante dos perigos e riscos de sua localidade (área)"],
            "cargaHoraria": "2 horas",            
            "instrutor": {
                "id":1,
                "nome": "Jiraylson jiban da silva",
                "desc": "Doutor especializado em ministrar treinamentos de NR55.",
            },
            "data": "2018-07-22",
            "termina": "2018-07-25",
            "endereco": "Rua Visconde do rio branco n², 1ºAndar",
            "local": "Corporativo I",
            "colaboradores": [
                { "nome": "Tiago", "setor": "TI", "local": "Corporativo" },
                { "id": 2, "matricula": "601200","nome": "Renan", "setor": "Coletor", "local": "IPA" }
            ]
        }
    ],
    "2018-07-05": [
        {
            "nome": "NR55",
            "id": "2",        
            "lotacao": "10",                
            "pontuacao":"15",
            "desc": "Norma para trabalhos em altura",
            "horario": { "inicio": "13:00", "fim": "14:45" },
            "cargaHoraria": "1 hora",
            "conteudoProgramatico": ["O que são Aspectos Ambientais", "O que são impactos Ambientais", "O que é Perigo; O que é risco", "Exposição", "Planilha de Aspectos e Impactos & Perigos e Riscos", "Objetivo: Orientar o participante dos perigos e riscos de sua localidade (área)"],
            "instrutor": {
                "id":1,
                "nome": "Jiraylson jiban da silva",
                "desc": "Doutor especializado em ministrar treinamentos de NR55.",
            },
            "data":"2018-07-05",
            "termina":"2018-07-07",
            "endereco": "Rua Visconde do rio branco n², 1ºAndar",
            "local": "Corporativo I",
            "colaboradores": [
                { "nome": "Tiago", "setor": "TI", "local": "Corporativo" },
                { "nome": "Renan", "setor": "Coletor", "local": "IPA" }
            ]
        }
    ],
    "2018-07-23": [
        {
            "nome": "NR55",
            "id": "4",
            "lotacao": "10",            
            "pontuacao":"15",
            "desc": "Norma para trabalhos em altura",
            "instrutor":{
                "id":2,
                "nome":"Armando cruz de madeira",
                "desc":"Doutor especializado em ministrar treinamentos de NR55.",
            },
            "horario": { "inicio": "08:00", "fim": "12:00" },
            "cargaHoraria": "3 horas",            
            "conteudoProgramatico": ["O que são Aspectos Ambientais", "O que são impactos Ambientais", "O que é Perigo; O que é risco", "Exposição", "Planilha de Aspectos e Impactos & Perigos e Riscos", "Objetivo: Orientar o participante dos perigos e riscos de sua localidade (área)"],
            "data":"2018-07-23",
            "termina":"2018-07-26",
            "endereco": "Rua Visconde do rio branco n², 1ºAndar",
            "local": "Corporativo I",
            "colaboradores": [
                { "nome": "Talles", "setor": "TI", "local": "Corporativo" },
                { "nome": "Caio", "setor": "Coletor", "local": "IPA" },
                { "nome": "Fernando A.", "setor": "DTA", "local": "IPA" },
                { "nome": "Renan Ska", "setor": "TI", "local": "Corp. II" },
                { "nome": "Caio", "setor": "Coletor", "local": "IPA" },
                { "nome": "Luan", "setor": "Cont.", "local": "CLIA" },
                { "nome": "Band", "setor": "Portuario", "local": "Santos/SP" },
                { "nome": "Dia%", "setor": "Varejo M.", "local": "São Paulo" },
                { "id": 1, "matricula": "601215","nome": "Tiago", "setor": "Portuario", "local": "Santos/SP" }
            ]
        },
        {
            "nome": "NR45",
            "id": "5",
            "lotacao": "10",            
            "pontuacao":"15",
            "desc": "Norma para trabalhos em altura",
            "instrutor": {
                "id": 2,
                "nome": "Armando cruz de madeira",
                "desc": "Doutor especializado em ministrar treinamentos de NR55.",
            },
            "horario": { "inicio": "13:00", "fim": "14:45" },
            "conteudoProgramatico": ["O que são Aspectos Ambientais", "O que são impactos Ambientais", "O que é Perigo; O que é risco", "Exposição", "Planilha de Aspectos e Impactos & Perigos e Riscos", "Objetivo: Orientar o participante dos perigos e riscos de sua localidade (área)"],
            "data":"2018-07-23",
            "termina":"2018-07-25",
            "cargaHoraria": "2 horas e 30 minutos",            
            "endereco": "Rua Visconde do rio branco n², 1ºAndar",
            "local": "Corporativo I",
            "colaboradores": [
                { "id": 1, "matricula": "601211","nome": "Tiago", "setor": "TI", "local": "Corporativo" },
                { "nome": "Renan", "setor": "Coletor", "local": "IPA" }
            ]
        }
    ]
};

var listaTreinamentosCalendarioFake = {
    "2018-07-22": "<div layout='row' layout-wrap><p class='eventTag blue-tag'>NR35</p><p class='eventTag red-tag'>NR55</p></div>",
    "2018-07-23": "<div layout='row' layout-wrap><p class='eventTag yellow-tag'>NR55</p><p class='eventTag purple-tag'>NR45</p></div>",    
    "2018-07-05": "<div layout='row' layout-wrap><p class='eventTag green-tag'>NR55</p></div>"
};

var statusTreinamento = [
    {"id":1,"sigla":"candidato","desc":"Candidatado"},
    {"id":2,"sigla":"treinamento","desc":"Em treinamento"},
    {"id":3,"sigla":"finalizado","desc":"Finalizou treinamento"},
    {"id":4,"sigla":"certificado-impresso","desc":"Certificado já emitido!"}
];

var treinamentoColaborador = [
    { "idTreinamento": 1, "idColaborador": 1, "status": statusTreinamento[0].id},
    { "idTreinamento": 1, "idColaborador": 2, "status": statusTreinamento[0].id},
    { "idTreinamento": 4, "idColaborador": 1, "status": statusTreinamento[0].id},
    { "idTreinamento": 5, "idColaborador": 1, "status": statusTreinamento[0].id},
    { "idTreinamento": 7, "idColaborador": 2, "status": statusTreinamento[0].id},
];

var avaliacoes = [
    {
        "id":1,
        "idTreinamento":1,
        "minimo":70,
        "perguntas":[
            {
                "id":1,
                "questao":"Quanto é 33 - 22 ?",
                "correta":2,
                "tempo": 9,
                "respostas":[
                    {"id":1,"desc":"55"},
                    {"id":2,"desc":"11"},
                    {"id":3,"desc":"12"},
                    {"id":4,"desc":"15"},
                    {"id":5,"desc":"Nenhuma das anteriores"},
                ]
            },
            {
                "id": 2,
                "questao": "O que é um ponto verde no alaska?",
                "correta": 1,
                "tempo": 3,
                "respostas": [
                    { "id": 1, "desc": "Pingreen" },
                    { "id": 2, "desc": "Pinguin" },
                    { "id": 3, "desc": "Abacate" },
                    { "id": 4, "desc": "Piccolo" },
                    { "id": 5, "desc": "Não sei!" },
                ]
            },
            {
                "id":3,
                "questao":"Quem é mais forte?",
                "correta":4,
                "tempo": 1,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Piccolo"},
                    {"id":3,"desc":"Vegeta"},
                    {"id":4,"desc":"Yamcha"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            }
        ]
    },
    {
        "id":2,
        "idTreinamento":2,
        "minimo": 50,
        "perguntas":[
            {
                "id":1,
                "questao":"Quem derrota o cell?",
                "correta":2,
                "tempo":10,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Gohan"},
                    {"id":3,"desc":"Trunks"},
                    {"id":4,"desc":"Yamcha"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 2,
                "questao": "O que é um ponto verde no alaska?",
                "correta": 1,
                "tempo": 10,
                "respostas": [
                    { "id": 1, "desc": "Pingreen" },
                    { "id": 2, "desc": "Pinguin" },
                    { "id": 3, "desc": "Abacate" },
                    { "id": 4, "desc": "Piccolo" },
                    { "id": 5, "desc": "Não sei!" },
                ]
            },
            {
                "id":3,
                "questao":"Qual é o nome do cavaleiro de cisne de Athena?",
                "correta":4,
                "tempo": 9,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Seiya"},
                    {"id":3,"desc":"Luffy"},
                    {"id":4,"desc":"Hyoga"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 4,
                "questao": "Nome da primeira filha de Gohan?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Videl" },
                    { "id": 2, "desc": "Bulma" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Nami" },
                    { "id": 5, "desc": "Pam" },
                ]
            },
            {
                "id": 5,
                "questao": "Qual é a cor do cavalo branco de napoleão?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Preto" },
                    { "id": 2, "desc": "Zebrado" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Azul" },
                    { "id": 5, "desc": "Branco" },
                ]
            }
        ]
    },
    {
        "id":3,
        "idTreinamento":3,
        "minimo": 50,
        "perguntas":[
            {
                "id":1,
                "questao":"Quem derrota o cell?",
                "correta":2,
                "tempo":10,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Gohan"},
                    {"id":3,"desc":"Trunks"},
                    {"id":4,"desc":"Yamcha"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 2,
                "questao": "O que é um ponto verde no alaska?",
                "correta": 1,
                "tempo": 10,
                "respostas": [
                    { "id": 1, "desc": "Pingreen" },
                    { "id": 2, "desc": "Pinguin" },
                    { "id": 3, "desc": "Abacate" },
                    { "id": 4, "desc": "Piccolo" },
                    { "id": 5, "desc": "Não sei!" },
                ]
            },
            {
                "id":3,
                "questao":"Qual é o nome do cavaleiro de cisne de Athena?",
                "correta":4,
                "tempo": 9,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Seiya"},
                    {"id":3,"desc":"Luffy"},
                    {"id":4,"desc":"Hyoga"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 4,
                "questao": "Nome da primeira filha de Gohan?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Videl" },
                    { "id": 2, "desc": "Bulma" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Chichi" },
                    { "id": 5, "desc": "Pam" },
                ]
            },
            {
                "id": 5,
                "questao": "Qual é a cor do cavalo branco de napoleão?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Preto" },
                    { "id": 2, "desc": "Zebrado" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Azul" },
                    { "id": 5, "desc": "Branco" },
                ]
            }
        ]
    },
    {
        "id":4,
        "idTreinamento":4,
        "minimo": 50,
        "perguntas":[
            {
                "id":1,
                "questao":"Quem derrota o cell?",
                "correta":2,
                "tempo":10,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Gohan"},
                    {"id":3,"desc":"Trunks"},
                    {"id":4,"desc":"Yamcha"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 2,
                "questao": "O que é um ponto verde no alaska?",
                "correta": 1,
                "tempo": 10,
                "respostas": [
                    { "id": 1, "desc": "Pingreen" },
                    { "id": 2, "desc": "Pinguin" },
                    { "id": 3, "desc": "Abacate" },
                    { "id": 4, "desc": "Piccolo" },
                    { "id": 5, "desc": "Não sei!" },
                ]
            },
            {
                "id":3,
                "questao":"Qual é o nome do cavaleiro de cisne de Athena?",
                "correta":4,
                "tempo": 9,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Seiya"},
                    {"id":3,"desc":"Luffy"},
                    {"id":4,"desc":"Hyoga"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 4,
                "questao": "Nome da primeira filha de Gohan?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Videl" },
                    { "id": 2, "desc": "Bulma" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Chichi" },
                    { "id": 5, "desc": "Pam" },
                ]
            },
            {
                "id": 5,
                "questao": "Qual é a cor do cavalo branco de napoleão?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Preto" },
                    { "id": 2, "desc": "Zebrado" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Azul" },
                    { "id": 5, "desc": "Branco" },
                ]
            }
        ]
    },
    {
        "id":5,
        "idTreinamento":5,
        "minimo": 50,
        "perguntas":[
            {
                "id":1,
                "questao":"Quem derrota o cell?",
                "correta":2,
                "tempo":10,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Gohan"},
                    {"id":3,"desc":"Trunks"},
                    {"id":4,"desc":"Yamcha"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 2,
                "questao": "O que é um ponto verde no alaska?",
                "correta": 1,
                "tempo": 10,
                "respostas": [
                    { "id": 1, "desc": "Pingreen" },
                    { "id": 2, "desc": "Pinguin" },
                    { "id": 3, "desc": "Abacate" },
                    { "id": 4, "desc": "Piccolo" },
                    { "id": 5, "desc": "Não sei!" },
                ]
            },
            {
                "id":3,
                "questao":"Qual é o nome do cavaleiro de cisne de Athena?",
                "correta":4,
                "tempo": 9,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Seiya"},
                    {"id":3,"desc":"Luffy"},
                    {"id":4,"desc":"Hyoga"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 4,
                "questao": "Nome da primeira filha de Gohan?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Videl" },
                    { "id": 2, "desc": "Bulma" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Chichi" },
                    { "id": 5, "desc": "Pam" },
                ]
            },
            {
                "id": 5,
                "questao": "Qual é a cor do cavalo branco de napoleão?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Preto" },
                    { "id": 2, "desc": "Zebrado" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Azul" },
                    { "id": 5, "desc": "Branco" },
                ]
            }
        ]
    },
    {
        "id":6,
        "idTreinamento":6,
        "minimo": 50,
        "perguntas":[
            {
                "id":1,
                "questao":"Quem derrota o cell?",
                "correta":2,
                "tempo":10,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Gohan"},
                    {"id":3,"desc":"Trunks"},
                    {"id":4,"desc":"Yamcha"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 2,
                "questao": "O que é um ponto verde no alaska?",
                "correta": 1,
                "tempo": 10,
                "respostas": [
                    { "id": 1, "desc": "Pingreen" },
                    { "id": 2, "desc": "Pinguin" },
                    { "id": 3, "desc": "Abacate" },
                    { "id": 4, "desc": "Piccolo" },
                    { "id": 5, "desc": "Não sei!" },
                ]
            },
            {
                "id":3,
                "questao":"Qual é o nome do cavaleiro de cisne de Athena?",
                "correta":4,
                "tempo": 9,
                "respostas":[
                    {"id":1,"desc":"Goku"},
                    {"id":2,"desc":"Seiya"},
                    {"id":3,"desc":"Luffy"},
                    {"id":4,"desc":"Hyoga"},
                    {"id":5,"desc":"Nenhum dos gueirros Z"},
                ]
            },
            {
                "id": 4,
                "questao": "Nome da primeira filha de Gohan?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Videl" },
                    { "id": 2, "desc": "Bulma" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Chichi" },
                    { "id": 5, "desc": "Pam" },
                ]
            },
            {
                "id": 5,
                "questao": "Qual é a cor do cavalo branco de napoleão?",
                "correta": 5,
                "tempo": 9,
                "respostas": [
                    { "id": 1, "desc": "Preto" },
                    { "id": 2, "desc": "Zebrado" },
                    { "id": 3, "desc": "Marron" },
                    { "id": 4, "desc": "Azul" },
                    { "id": 5, "desc": "Branco" },
                ]
            }
        ]
    }
];

var colaboradorAvaliacao = {

}
var opinioes = [
    {"id":1,"desc":"Ótimo"},
    {"id":2,"desc":"Regular"},
    {"id":3,"desc":"Péssimo"}
];
var avaliacaoReacao = [
    {
        "id": 1, 
        "nome":"Conteúdo Programa",
        "perguntas":[
            {
                "id":1,
                "pergunta": "Conteúdo do curso",                
                "opinioes":opinioes
            },
            {
                "id":2,
                "pergunta": "Obtenção de novos conhecimentos",                
                "opinioes":opinioes
            },
            {
                "id":3,
                "pergunta": "Possibilidade de aplicação na rotina de trabalho",                
                "opinioes":opinioes
            }
        ]
    },
    {
        "id": 2, 
        "nome":"Infraestrutura e logística",
        "perguntas":[
            {
                "id":1,
                "pergunta": "Adequação das instalações e equipamentos",                
                "opinioes":opinioes
            },
            {
                "id":2,
                "pergunta": "Local",                
                "opinioes":opinioes
            },
            {
                "id":3,
                "pergunta": "Carga horária (duração do curso)",                
                "opinioes":opinioes
            }
        ]
    },
    {
        "id": 3, 
        "nome":"Atuação do instrutor/palestrante",
        "perguntas":[
            {
                "id":1,
                "pergunta": "Conhecimento do instrutor/palestrante",                
                "opinioes":opinioes
            },
            {
                "id":2,
                "pergunta": "Forma/método de aplicação do conteúdo do curso",                
                "opinioes":opinioes
            },
            {
                "id":3,
                "pergunta": "Apresentação de aplicações práticas dos temas tratados",                
                "opinioes":opinioes
            },
            {
                "id":4,
                "pergunta": "Verificação do entendimento dos temas pelo participante",                
                "opinioes":opinioes
            }
        ]
    },
    {
        "id": 4, 
        "nome":"Atuação dos participantes",
        "perguntas":[
            {
                "id":1,
                "pergunta": "Facilidade de entendimento sobre os temas tratados",                
                "opinioes":opinioes
            },
            {
                "id":2,
                "pergunta": "Relação com os outros participantes",                
                "opinioes":opinioes
            },
            {
                "id":3,
                "pergunta": "Considero a minha participação",                
                "opinioes":opinioes
            },
            {
                "id":4,
                "pergunta": "Relação com o instrutor",                
                "opinioes":opinioes
            }
        ]
    },
]