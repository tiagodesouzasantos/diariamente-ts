angular.module('bandTrainingCalendar', [
    'ngMaterial',
    'ngAnimate',
    'performance',
    'ngSanitize',
    'ui.router',
    'gridster',
    'ui.carousel',
    'chart.js',
    'home',
    'menu',
    'instrutor',
    'admin',
    'initial',
    'rzModule',
    'dbServer',
    'mapsService',
    'timeService',
    'materialCalendar',
    'treinamento',
    'text',
    'recoverPass',
    'meusDados'
])

.config(function($mdThemingProvider, $stateProvider, $urlRouterProvider, $mdDateLocaleProvider) {



    // Configuração de tema do Angular Material
    $mdThemingProvider
        .theme('default')
        .primaryPalette('light-blue')
        .accentPalette('light-blue');

    // Configuração de rotas
    $stateProvider
        .state('initial', {
            url: '/initial',
            views: {
                'content@': {
                    templateUrl: 'modules/initial/index.html',
                    controller: 'initialController as initial'
                }
            }
        })

    $stateProvider
        .state('recoverpass', {
            url: '/recoverpass/:recoverpass',
            views: {
                'content@': {
                    templateUrl: 'modules/recoverpass/index.html',
                    controller: 'recoverPassController as recoverPass'
                }
            }
        })

    .state('menu', {
        abstract: true,
        views: {
            'content@': {
                templateUrl: 'modules/menu/index.html',
                controller: 'menuController as menu'
            }
        }
    })

    // INICIO PUBLICACOES
    .state('home', {
            parent: 'menu',
            url: '/home',
            views: {
                'main@menu': {
                    templateUrl: 'modules/home/index.html',
                    controller: 'homeController as home'
                }
            }
        })
        .state('treinamento', {            
            parent: 'menu',
            url: '/treinamento',
            params: { treinamento: null},
            cache: false,
            views: {
                'main@menu': {
                    templateUrl: 'modules/treinamento/index.html',
                    controller: 'treinamentoController as treinamento'
                }
            }
        })

        .state('meusDados', {
            parent: 'menu',
            url: '/meusDados',
            views: {
                'main@menu': {
                    templateUrl: 'modules/meusDados/index.html',
                    controller: 'meusDadosController as meusDados'
                }
            }
        })
        .state('admin', {
            parent: 'menu',
            url: '/admin',
            views: {
                'main@menu': {
                    templateUrl: 'modules/admin/index.html',
                    controller: 'adminController as admin'
                }
            }
        })
        .state('instrutor', {
            parent: 'menu',
            url: '/instrutor',
            views: {
                'main@menu': {
                    templateUrl: 'modules/instrutor/index.html',
                    // controller: 'instrutorController as instrutor'
                }
            }
        })



    $urlRouterProvider.otherwise('initial');
    //Formato Brazileiro date
    $mdDateLocaleProvider.formatDate = function(dateString) {
        var data;
        if (dateString === undefined) {
            data = '';
        } else {
            data = moment(dateString).format('DD/MM/YYYY');
        }
        return data;
    };

    $mdDateLocaleProvider.parseDate = function(dateString) {
        var m = moment(dateString, 'DD/MM/YYYY', true);
        return m.isValid() ? m.toDate() : new Date(NaN);
    };

    //Tradução Calendar
    $mdDateLocaleProvider.months = ['janeiro', 'fereveiro', 'março', 'abril', 'maio', 'junho', 'julho', 'agosto', 'setembro', 'outubro', 'novembro', 'dezembro'];
    $mdDateLocaleProvider.shortMonths = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'];
    $mdDateLocaleProvider.shortDays = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'];

}).run(function($rootScope, $state, session) {

    var routerWithLogin = ['home', 'menu', 'treinamento', 'meusDados', 'admin', 'instrutor'];

    $rootScope.$on('$locationChangeSuccess', function(event, next, current) {
        for (var route in routerWithLogin) {
            var foundedUrl = next.indexOf(routerWithLogin[route]);
            if (foundedUrl >= 0) {
                var splitedUrl = next.substr((foundedUrl), next.length).split('/');
                if (routerWithLogin[route] == splitedUrl[(splitedUrl.length - 1)]) {
                    session.valideSession(routerWithLogin[route]);
                    break;
                }
            }
        }
        var url = next.split('/');
        $rootScope.labelColors = url[4] == "home"?true:false;
    })
});