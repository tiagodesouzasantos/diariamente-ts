angular.module('meusDados')
    .service('meusDadosService', function($q, db, session) {
        return {
            save: function(usuario) {
                var updateUserProm = $q.defer();
                // var usuario = JSON.parse(session.getData('authData'));
                var saveUser = db.dbActions('updateUserData', usuario, 'login');
                saveUser.then(function(updateUserResult) {
                    if (updateUserResult.success == undefined) {
                        updateUserProm.reject(updateUserResult.error);
                    } else {
                        updateUserProm.resolve(updateUserResult.success);
                    }
                }).catch(function(saveUserError) {
                    updateUserProm.reject(saveUserError);
                });
                return updateUserProm.promise;

            }
        }
    })