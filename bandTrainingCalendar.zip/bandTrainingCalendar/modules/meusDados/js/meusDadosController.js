angular.module('meusDados')
    .controller('meusDadosController',
        function($scope, meusDadosService, dialogService, session, $mdDialog, msgsService, $state) {
            $scope.init = function() {
                var userData = JSON.parse(session.getData('authData'));
                $scope.userLogin = userData;
                $scope.login = $scope.userLogin.user;          
            }
                
            $scope.save = function(){
                $scope.progress = true;
                
                meusDadosService.save($scope.login).then(function(saveUsuarioResult) {                    
                    $scope.userLogin.user.email = $scope.login.email;
                    session.setData('authData', JSON.stringify($scope.userLogin));
                    $scope.progress = false;
                    $scope.dialogMsg("Deu certo!", saveUsuarioResult);
                }).catch(function(saveUsuarioError) {
                    $scope.progress = false;
                    $scope.dialogMsg("Problemas!", saveUsuarioError);
                });
            }  
            $scope.dialogMsg = function(title, moduleMsg) {
                var confirmeJson = {
                    "title": title,
                    "content": msgsService.getMsg(moduleMsg.module, moduleMsg.msg),
                    "buttonOk": "Ok"
                };
                dialogService.confirm(confirmeJson).then(function() {
                    $state.go("home", {}, { reload: true });
                }).catch(function() {
                    $scope.init();
                });
            }     
            $scope.saveDisable = function(login,primeiroEmail){
                if (login.email == primeiroEmail && login.senha == undefined){
                    return true;
                }else{
                    return (login.senha != '' ? (login.senha != login.rsenha ? true : false) : true);
                }
            }
        });