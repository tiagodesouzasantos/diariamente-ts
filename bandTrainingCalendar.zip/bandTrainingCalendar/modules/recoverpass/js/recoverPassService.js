angular.module('recoverPass')
    .service('recoverPassService',
        function($q, $http, db, msgsService) {
            return {                
                getToken: function(token) {
                    var getTokenProm = $q.defer();
                    db.dbActions('getToken', token, 'login')
                        .then(function (tokenResult) {
                            if (tokenResult.validToken){
                                getTokenProm.resolve(tokenResult);
                            }else{
                                getTokenProm.reject(msgsService.getMsg('usuario', 6));
                            }
                        }).catch(function (tokenError) {
                            getTokenProm.reject(msgsService.getMsg('app', 3));
                        });
                    return getTokenProm.promise;
                },
                updatePass: function(user) {
                    var updatePassProm = $q.defer();
                    db.dbActions('updatePass', user, 'login')
                        .then(function (updateResult) {
                            if (updateResult.updated && updateResult.deleted){
                                updatePassProm.resolve(msgsService.getMsg('app', 1));
                            }else{
                                updatePassProm.reject(msgsService.getMsg('usuario', 3));
                            }
                        }).catch(function (updateError) {
                            updatePassProm.reject(msgsService.getMsg('usuario', 3));
                        });
                    return updatePassProm.promise;
                }
            }
        }
    )