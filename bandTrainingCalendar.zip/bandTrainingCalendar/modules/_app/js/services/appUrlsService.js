angular.module('bandTrainingCalendar')
    .service('appUrls', [function() {
        return {
            getEnv: function() {
                var environments = {
                    "localhost": "dev",
                    "dev": "dev",
                    "web": "web"
                };
                var httpHost = window.location.hostname;
                var firstNameHost = httpHost.split('.');
                return environments[firstNameHost[0]];
            },
            getUrl: function(url) {
                var urlMaps = {
                    "dev": {
                        "app": "http://dev.new.band/treinamentos/services/v1/"
                    },
                    "web": {
                        "app": "http://web.new.band/treinamentos/services/v1/"
                    }
                };
                return urlMaps[this.getEnv()][url];
            }
        }
    }])