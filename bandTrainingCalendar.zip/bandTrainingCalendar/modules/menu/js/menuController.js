angular.module('menu')
    .controller('menuController',
        function ($mdBottomSheet,$scope, $mdSidenav, $state,  session) {
            $scope.init = function() {
                var login = JSON.parse(session.getData('authData'));
                $scope.user = login.user;
                $scope.showMenus = JSON.parse(session.getData('configs'));
            }
                
            $scope.items = [
                {name: 'Obrigatório',class: 'red-tag'},
                {name: 'Em aberto',class: 'blue-tag'},
                // {name: 'Em avaliação',class: 'yellow-tag'},
                {name: 'Inscrito',class: 'purple-tag'},
                {name: 'Concluido',class: 'green-tag'},
                {name: 'Não participou',class: 'grey-tag'},
            ];

            $scope.colorLabels = function(){
                $scope.showGridBottomSheet();
            }
            $scope.close = function(menuClose) {
                $mdSidenav(menuClose).close()
                    .then(function() {
                        // $log.debug("close LEFT is done");
                    }).catch(function(evt) {
                        // console.log(evt);
                    });
            }

            $scope.toogleSideNav = function(menuClose) {
                $mdSidenav(menuClose).toggle();
                setTimeout(function() {
                    $scope.$broadcast('reCalcViewDimensions');
                }, 1)
            }

            $scope.goto = function(state) {
                if (state == "exit") {
                    sessionStorage.clear()
                    $state.go("initial");
                }
                $state.go(state);
                $scope.close('left');
            }

            $scope.showGridBottomSheet = function () {
                $mdBottomSheet.show({
                    templateUrl: 'modules/menu/color-labels.html',
                    controller: 'menuController',
                    clickOutsideToClose: true
                }).then(function (result) {
                    // console.log('showGridBottomSheet-result', result);
                }).catch(function (error) {
                    // console.log('showGridBottomSheet-error', error);
                    // User clicked outside or hit escape
                });
            };

        }
    );