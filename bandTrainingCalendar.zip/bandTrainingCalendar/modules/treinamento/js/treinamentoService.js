angular.module('treinamento')
    .service('treinamentoService', 
        function ($q, $http, db, session, time, msgsService) {
            return {                
                candidaturaHabilitada:function(treinamento){
                    var habilitada = false;
                    var validacoes = ["treinamentoValidaData","lotacaoTreinamento"];
                    for (var i = 0; i < validacoes.length;i++){                        
                        switch (validacoes[i]){
                            case 'treinamentoValidaData':
                                habilitada = this.treinamentoValidaData(treinamento,3);
                            break;
                            case 'lotacaoTreinamento':
                                habilitada = this.lotacaoTreinamento(treinamento);
                            break;
                            default:
                                console.log('default',treinamento);
                        }
                        if(habilitada){
                            break;
                        }
                    }
                    return habilitada;
                },
                treinamentoValidaData:function(treinamento,addDays){
                    var habilitada = false;                    
                    if (treinamento.data != null) {
                        // Só pode se candidatar no prazo de 3 dias
                        var today = new Date();
                        today.setDate(today.getDate() + addDays);

                        var dtT = treinamento.data.split('-');
                        var passouData = new Date(dtT[0], (dtT[1] - 1), dtT[2]) - today;
                        habilitada = passouData > 0 ? false : true;
                    }
                    return habilitada;
                },
                lotacaoTreinamento: function (treinamento){
                    var habilitada = false;  
                    if (treinamento.data != null) {
                        habilitada = treinamento.lotacao - treinamento.colaboradores.length <= 0 ? true : false;
                    }
                    return habilitada;
                },
                acessoAvaliacoes: function (treinamento,usuario){
                    var acessaAvalProm = $q.defer();
                    var liberado = this.treinamentoValidaData(treinamento,0);
                    // if(liberado){
                        this.usuarioCandidatado(treinamento, usuario).then(function (candidatadoResult) { 
                            var avaliacaoLiberada = (candidatadoResult.length > 0 && liberado)?true:false;
                            var resolveResult = { "liberada": avaliacaoLiberada, "candidatado": candidatadoResult };
                            acessaAvalProm.resolve(resolveResult);
                        }).catch(function (candidatadoError) { 
                            console.log('candidatadoError', candidatadoError, liberado);
                        });
                    // }else{
                    //     acessaAvalProm.resolve({ "liberada": liberado, "candidatado": [] });
                    // }
                    return acessaAvalProm.promise;
                },
                usuarioCandidatado: function (treinamento, usuario){
                    var candidatadoProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": 'consultaCandidatoTreinamento', "treinamento": treinamento, "usuario": usuario }, 'treinamento-vetorh')
                        .then(function (candidaturaResult) {
                            candidatadoProm.resolve(candidaturaResult.candidatura);
                        }).catch(function (candidaturaError) {
                            console.log('candidaturaError', candidaturaError);
                            candidatadoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return candidatadoProm.promise;
                },
                insereCandidatura:function(treinamento,usuario){
                    var candidaturaProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": 'insereCandidato', "treinamento": treinamento, "usuario": usuario }, 'treinamento-vetorh')
                        .then(function (candidaturaResult) {
                            if (candidaturaResult.candidatura){
                                candidaturaProm.resolve(msgsService.getMsg('treinamentos', 1));
                            }else{
                                candidaturaProm.reject(msgsService.getMsg('treinamentos', 2));
                            }                            
                        }).catch(function (candidaturaError) {
                            console.log('candidaturaError', candidaturaError);
                            candidaturaProm.reject(msgsService.getMsg('app', 3));
                        });
                    return candidaturaProm.promise;
                },
                cancelaCandidatura:function(treinamento,usuario){
                    var candidaturaProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": 'cancelaCandidato', "treinamento": treinamento, "usuario": usuario }, 'treinamento-vetorh')
                        .then(function (candidaturaResult) {
                            console.log('candidaturaResult', candidaturaResult);
                            candidaturaProm.resolve(candidaturaResult);
                        }).catch(function (candidaturaError) {
                            console.log('candidaturaError', candidaturaError);
                            candidaturaProm.reject(msgsService.getMsg('app', 3));
                        });
                    return candidaturaProm.promise;
                }
            }
        }
    )