angular.module('home')
    .controller('homeController',
        function($filter, $state, $scope, homeService, $rootScope, $mdDialog, dateService,$q) {
            $scope.init = function() {
                $rootScope.showLoading = true;
                $scope.limitDesc = 80;
                $scope.calendario = false;
                $scope.progress = false;
                $scope.tooltips = true;
                $scope.desabilitado = true;
                $scope.selectedDate = null;
                $scope.firstDayOfWeek = 0;
                $scope.getDateCalendar();
                $scope.loadData();
                homeService.limpTreinCanc()
            }
            
            $scope.loadData = function() {
                var datas = {"treinamentos": homeService.getTreinamentos()};
                $q.all(datas).then(function(datasResult){ 
                    console.log('datasResult',datasResult);                
                    $scope.datejson = datasResult.treinamentos.calendario;
                    $scope.treinamentosDoDia = datasResult.treinamentos.dataTreinamentos;
                    $scope.treinamentosColab = datasResult.treinamentos.treinamentosColab;
                    $scope.calendario = true;
                    $rootScope.showLoading = false;
                }).catch(function(datasError){
                    console.log('datasError',datasError);
                });
            }
            $scope.getDateCalendar = function(){
                var data = dateService.formatDateDB(new Date());
                data = data.split('-');
                $scope.data = { "m": data[1], "y": data[0]};
                // console.log('$scope.data', $scope.data);
            }

            $scope.dialogListaVinculados = function(lista) {
                $scope.listaAtual = $scope.treinamentosColab[lista.id_treinamento][lista.id_turma];
                // console.log('lista', $scope.listaAtual);
                return $mdDialog.show({
                    controller: function(copiaScope) {
                        return copiaScope;
                    },
                    controllerAs: 'home',
                    locals: {
                        copiaScope: $scope
                    },
                    templateUrl: 'modules/home/lista-vinculados.html',
                    clickOutsideToClose: true
                }).then(function(){}).catch(function(){
                    $scope.searchList = '';
                });
            }

            $scope.closeModal = function() {
                $mdDialog.hide();
            }

            $scope.addColaboradores = function(treinamento) {                
                treinamento.btnCancelar = homeService.getTagColorTraining(treinamento);
                treinamento.colaboradores = $scope.treinamentosColab[treinamento.id_treinamento][treinamento.id_turma];
                $state.go('treinamento',{"treinamento":treinamento});
            };
            $scope.dayClick = function(date) {                
                $scope.diaSelecionado = $filter("date")(date, "dd/MM/yy");            
                $scope.selectedDateDB = $filter("date")(date, "yyyy-MM-dd");
                // var datejson = treinamentosFake;
                $scope.treinamentos = $scope.treinamentosDoDia[$scope.selectedDateDB];
            };
            $scope.prevMonth = function(data) {
                $scope.msg = "You clicked (prev) month " + data.month + ", " + data.year;
            };
            $scope.nextMonth = function(data) {
                $scope.msg = "You clicked (next) month " + data.month + ", " + data.year;
            };


            $scope.setDayContent = function(date) {
                var dateDB = dateService.formatDateDB(date);
                var contentDate = "";

                if ($scope.datejson[dateDB] != undefined) {
                    contentDate = $scope.datejson[dateDB];
                }
                return contentDate;
            };
        });