angular.module('home')
    .service('homeService',
    function ($q, db, session, msgsService) {
            return {
                getTreinamentos:function(){
                    var treinamentosProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": "listaTreinamentos", "usuario": JSON.parse(session.getData('authData'))}, 'treinamento-vetorh')
                        .then(function (treinamentosResult) {                            
                            treinamentosProm.resolve(treinamentosResult);
                        }).catch(function (treinamentosError) {
                            console.log('gettreinamentos-error', treinamentosError);
                            treinamentosProm.reject(msgsService.getMsg('app', 3));
                        });
                    return treinamentosProm.promise;
                },
                limpTreinCanc:function(){
                    var limpTreinCancProm = $q.defer();
                    db.dbActions('treinamento', { "actionVth": "limpTreinCanc", "usuario": JSON.parse(session.getData('authData'))}, 'treinamento-vetorh')
                        .then(function (limpTreinCancResult) {     
                            // console.log('limpTreinCancResult', limpTreinCancResult);
                            limpTreinCancProm.resolve(limpTreinCancResult);
                        }).catch(function (limpTreinCancError) {
                            console.log('getlimpTreinCanc-error', limpTreinCancError);
                            limpTreinCancProm.reject(msgsService.getMsg('app', 3));
                        });
                    return limpTreinCancProm.promise;
                },
                getTagColorTraining:function(treinamento){
                    var id = 'tag' + treinamento.id_treinamento + '' + treinamento.id_turma;
                    var htmlTag = angular.element(document.querySelector('#' + id)).attr('class').split(' ');
                    return htmlTag[1] == 'purple-tag'?true:false;
                }
            }
        }
    )