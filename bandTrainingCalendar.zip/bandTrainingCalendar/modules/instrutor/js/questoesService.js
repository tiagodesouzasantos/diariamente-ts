angular.module('instrutor')
    .service('questoesService',
    function ($q, $http, db, session, $timeout, msgsService) {
            return {
                getQuestoes: function() {    
                    var questoesProm = $q.defer();
                    db.dbActions('listaQuestoes', {}, 'questoes_adm')
                        .then(function (questoesResult) {
                            questoesProm.resolve(questoesResult.questoes);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                saveQuestoes: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('saveQuestoes', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                atualizaQuestoes: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('atualizaQuestoes', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                deleteQuestoes: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('deleteQuestoes', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                deleteResposta: function(data) {   
                    var questoesProm = $q.defer();
                    db.dbActions('deleteResposta', data, 'questoes_adm')
                        .then(function (questoesResult) {
                            console.log('questoesResult', questoesResult);
                            questoesProm.resolve(questoesResult.data);
                        }).catch(function (questoesError) {
                            console.log('questoesError', questoesError);
                            questoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return questoesProm.promise;
                },
                normalizacaoFrontQst:function(questao){
                    var corretaPosition='0';
                    for (var i = 0; i < questao.respostas.length;i++){
                        questao.respostas[i].ordem = questao.respostas[i].ordem*1;
                        if (questao.respostas[i].correta=='1'){
                            corretaPosition = i;
                        }
                    }
                    questao.correta = corretaPosition;
                    questao.questao = { "desc": questao.desc, "id": questao.id, "tempo": questao.tempo*1};
                    return questao;
                }
            }
        }
    )