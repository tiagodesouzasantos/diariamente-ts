angular.module('instrutor')
    .controller('instrutorAvaliacaoController',
    function ($rootScope, $state, session, instrutorAvaliacaoService, $mdDialog, $element,$scope) {
            var instAvalCtrl = this;
            instAvalCtrl.init = function () {
                instAvalCtrl.loadAvaliacoes();
                instAvalCtrl.questoes = null;
                instAvalCtrl.cardSelecionado = null;
                instAvalCtrl.progress = false;
                instAvalCtrl.avaliacaoEmEdicao = false;
            }
            instAvalCtrl.loadAvaliacoes = function(){
                $rootScope.showLoading = true;
                var avaliacoes = instrutorAvaliacaoService.getListaAvaliacao();
                avaliacoes.then(function (listaAvaliacaoResult) {
                    instAvalCtrl.getListaAvaliacao = listaAvaliacaoResult.avaliacoes;
                    $rootScope.showLoading = false;
                }).catch(function (listaAvaliacaoError) {
                    $rootScope.showLoading = false;                     
                    console.log('listaAvaliacaoError', listaAvaliacaoError);
                });
            }
            instAvalCtrl.autoCompleteDescAva = function (desc) {
                instAvalCtrl.novaavaliacao = desc.desc;
            }
            instAvalCtrl.getQuestoes = function(item){
                $rootScope.showLoading = true;
                instAvalCtrl.cardSelecionado = item;
                instAvalCtrl.indexCard = item.id; 
                var questoes = instrutorAvaliacaoService.getListaQuestoesAvaliacao(instAvalCtrl.cardSelecionado);
                questoes.then(function(questoesResult){
                    instAvalCtrl.questoes = questoesResult.questoes;
                    $rootScope.showLoading = false; 
                }).catch(function (questoesError) { 
                    $rootScope.showLoading = false;                    
                });
            }
            instAvalCtrl.clearQuest = function(){
                instAvalCtrl.questoes = null;
                instAvalCtrl.indexCard = null;
            }
            
            instAvalCtrl.loadDataAbreDialog = function (template) {
                switch (template) {
                    case 'novaAvaliacao':
                        instAvalCtrl.loadNovaAvaliacao(template);
                        break;
                    default:
                        console.log('Escolha uma ação');
                }
            }

            instAvalCtrl.closeDialog = function(){
                $mdDialog.hide();
            }
            instAvalCtrl.openDialog = function(template){
                var templates = {
                    "novaAvaliacao": 'modules/instrutor/templates/novaAvaliacao.html'
                }
                return $mdDialog.show({
                    controller: function (copiaScope) {
                        return copiaScope;
                    },
                    controllerAs: 'instAvalCtrl',
                    locals: {
                        copiaScope: instAvalCtrl
                    },
                    templateUrl: templates[template],
                    clickOutsideToClose: true
                }).then(function (modalResult) { 
                    instAvalCtrl.nva = {};
                }).catch(function (modalError) { 
                    instAvalCtrl.nva = {};
                });
            }           
            instAvalCtrl.loadNovaAvaliacao = function(template){
                $rootScope.showLoading = true;                
                var questoes = instrutorAvaliacaoService.getQuestoesData();
                questoes.then(function(getQuestoesResult){
                    instAvalCtrl.listaQuestoes = getQuestoesResult.questoes;
                    $rootScope.showLoading = false;  
                    instAvalCtrl.openDialog(template);  
                }).catch(function (getQuestoesError) {
                    console.log('getQuestoesError', getQuestoesError);
                });
            }   
            
            instAvalCtrl.editAvaliacao = function(avaliacao){
                instAvalCtrl.avaliacaoEmEdicao = true;
                instAvalCtrl.nva = { 
                    "avaliacao": avaliacao,
                    "questoesSelecionadas": instAvalCtrl.questoes
                };
                instAvalCtrl.loadNovaAvaliacao('novaAvaliacao');
            }
            instAvalCtrl.atualizandoAvalSelectOptions = function(id){
                for (var i = 0; i < instAvalCtrl.nva.questoesSelecionadas.length;i++){
                    if(instAvalCtrl.nva.questoesSelecionadas[i].id==id){
                        return true;
                    }
                }                   
                return false;
            }
            instAvalCtrl.saveAvaliacao = function(){
                instAvalCtrl.progress = true;
                console.log('instAvalCtrl.nva', instAvalCtrl.nva);
                // var save = instrutorAvaliacaoService.saveAvaliacao(instAvalCtrl.nva);
                // save.then(function (saveAvaliacaoResult) {
                //     instAvalCtrl.progress = false;
                //     instAvalCtrl.closeDialog();
                //     instAvalCtrl.init();
                // }).catch(function (saveAvaliacaoError) {
                //     console.log('saveAvaliacaoError', saveAvaliacaoError);
                // });
            }
            instAvalCtrl.atualizaAvaliacao = function(){
                instAvalCtrl.progress = true;                
                var atualizar = instrutorAvaliacaoService.atualizaAvaliacao(instAvalCtrl.nva);
                atualizar.then(function (atualizarAvaliacaoResult) {
                    instAvalCtrl.progress = false;
                    // instAvalCtrl.closeDialog();
                    // instAvalCtrl.init();
                    // console.log('atualizarAvaliacaoResult', atualizarAvaliacaoResult);

                }).catch(function (atualizarAvaliacaoError) {
                    console.log('atualizarAvaliacaoError', atualizarAvaliacaoError);
                });
            }
            instAvalCtrl.deleteAvaliacao = function(idAvaliacao){                
                var deleta = instrutorAvaliacaoService.deleteAvaliacao(idAvaliacao);
                deleta.then(function (deletaResult) {
                    instAvalCtrl.init();                  
                }).catch(function (deletaError) {
                    console.log('deletaError', deletaError);
                });
            }
            instAvalCtrl.deleteQuestaoAvaliacao = function (idAvaliacao,idQuestao,index){                
                $rootScope.showLoading = true;                                
                var deleta = instrutorAvaliacaoService.deleteQuestaoAvaliacao({ "fk_avaliacao_prova": idAvaliacao, "fk_avaliacao_questoes": idQuestao});
                deleta.then(function (deletaResult) {
                    instAvalCtrl.questoes.splice(index, 1);
                    $rootScope.showLoading = false;                    
                }).catch(function (deletaError) {
                    console.log('deletaError', deletaError);
                });
            }
        });