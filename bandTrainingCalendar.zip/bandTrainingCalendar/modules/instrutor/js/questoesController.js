angular.module('instrutor')
    .controller('questoesController',
        function ($rootScope, $state, session, $mdDialog,questoesService) {
            var questCtrl = this;
            questCtrl.init = function(){
                questCtrl.initVars();
                questCtrl.loadQuestoes(); 
                questCtrl.nvaInit();    
            }
            questCtrl.initVars = function(){
                questCtrl.progress = false;
                questCtrl.respostas = null;
                questCtrl.qstSelecionada = null;
                questCtrl.indexResp = null;
            }
            questCtrl.nvaInit = function(){
                questCtrl.modoEdicao = false;
                questCtrl.respostaPadrao = { "desc": "", "ordem": 0, "correta": 0 };
                questCtrl.nva = {};
                questCtrl.nva.respostas = [JSON.parse(JSON.stringify(questCtrl.respostaPadrao))];
            }

            questCtrl.addResposta = function(){
                var novaResposta = [];
                questCtrl.respostaPadrao.ordem++;
                questCtrl.nva.respostas.push(JSON.parse(JSON.stringify(questCtrl.respostaPadrao)));                
            }

            questCtrl.loadQuestoes = function(){
                $rootScope.showLoading = true;
                var questoes = questoesService.getQuestoes();
                questoes.then(function (questoesResult) { 
                    console.log('questoesResult', questoesResult);
                    questCtrl.questoesList = questoesResult;
                    $rootScope.showLoading = false;                    
                }).catch(function (questoesError) { 
                    console.log('questoesError', questoesError);
                });
            }
            questCtrl.getRespostas = function(item){
                questCtrl.qstSelecionada = item;
                questCtrl.indexResp = item.id;
                questCtrl.respostas = item.respostas;
            }
            questCtrl.clearResp = function(){
                questCtrl.respostas = null;
                questCtrl.indexResp = null;
                questCtrl.qstSelecionada = null;                
            }
            questCtrl.closeDialog = function () {
                $mdDialog.hide();
            }
            questCtrl.openDialog = function (template) {
                var templates = {
                    "novaResposta": 'modules/instrutor/templates/novaResposta.html',
                    "novaQuestao": 'modules/instrutor/templates/novaQuestao.html'
                }
                return $mdDialog.show({
                    controller: function (copiaScope) {
                        return copiaScope;
                    },
                    controllerAs: 'questCtrl',
                    locals: {
                        copiaScope: questCtrl
                    },
                    templateUrl: templates[template],
                    clickOutsideToClose: true
                }).then(function (modalResult) {
                    questCtrl.nvaInit();
                }).catch(function (modalError) {
                    questCtrl.nvaInit();
                });
            }   
            questCtrl.editQuestoes = function(){
                questCtrl.openDialog('novaQuestao');
                questCtrl.modoEdicao = true;
                questCtrl.nva = questoesService.normalizacaoFrontQst(questCtrl.qstSelecionada);
                questCtrl.respostaPadrao.ordem = (questCtrl.nva.respostas.length);
                console.log('questCtrl.qstSelecionada', questCtrl.qstSelecionada);
            }
            questCtrl.saveQuestoes = function(){
                questCtrl.progress = true;
                var questoes = questoesService.saveQuestoes(questCtrl.nva);
                questoes.then(function (questoesResult) {
                    questCtrl.progress = false;
                    questCtrl.closeDialog();
                    questCtrl.init();
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                });
            }
            questCtrl.atualizaQuestoes = function(){
                questCtrl.progress = true;
                var questoes = questoesService.atualizaQuestoes(questCtrl.nva);
                questoes.then(function (questoesResult) {
                    questCtrl.progress = false;
                    questCtrl.closeDialog();
                    questCtrl.init();
                    // console.log('questoesResult', questoesResult);
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                });
            }
            questCtrl.removerNvaResp = function(index){
                questCtrl.nva.respostas.splice(index,1);
            }

            questCtrl.deleteQuestoes = function(){
                $rootScope.showLoading = true;
                var questoes = questoesService.deleteQuestoes(questCtrl.qstSelecionada);
                questoes.then(function (questoesResult) {
                    $rootScope.showLoading = false;
                    questCtrl.init();
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                    questCtrl.init();
                });
            }
            questCtrl.deleteResposta = function(resposta,index){
                $rootScope.showLoading = true;
                var questoes = questoesService.deleteResposta(resposta);
                questoes.then(function (questoesResult) {
                    $rootScope.showLoading = false;
                    questCtrl.respostas.splice(index,1)
                }).catch(function (questoesError) {
                    console.log('questoesError', questoesError);
                    questCtrl.init();
                });
            }
    });