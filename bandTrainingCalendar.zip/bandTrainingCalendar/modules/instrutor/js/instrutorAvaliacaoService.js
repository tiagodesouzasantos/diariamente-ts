angular.module('instrutor')
    .service('instrutorAvaliacaoService',
        function($q, $http, db, session, $timeout,msgsService) {
            return {
                getListaAvaliacao: function() {    
                    var listaAvaliacaoProm = $q.defer();
                    db.dbActions('listaAvaliacao', {}, 'avaliacoes_adm')
                        .then(function (avaliacaoListaResult) {
                            listaAvaliacaoProm.resolve(avaliacaoListaResult);
                        }).catch(function (avaliacoesError) {
                            console.log('gettreinamentos-error', avaliacoesError);
                            listaAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return listaAvaliacaoProm.promise;
                },
                getListaQuestoesAvaliacao: function(avaliacao) {    
                    var listaQuestoesAvaliacaoProm = $q.defer();
                    db.dbActions('listaQuestoesAvaliacao', { "idAvaliacao": avaliacao.id}, 'avaliacoes_adm')
                        .then(function (questoesAvaliacaoResult) {
                            listaQuestoesAvaliacaoProm.resolve(questoesAvaliacaoResult);
                        }).catch(function (questoesAvaliacaoError) {
                            console.log('gettreinamentos-error', questoesAvaliacaoError);
                            listaQuestoesAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return listaQuestoesAvaliacaoProm.promise;
                },
                getQuestoesData:function(){
                    var listaQuestoesProm = $q.defer();
                    db.dbActions('listaQuestoes', {}, 'avaliacoes_adm')
                        .then(function (questoesResult) {
                            listaQuestoesProm.resolve(questoesResult);
                        }).catch(function (questoesError) {
                            console.log('gettreinamentos-error', questoesError);
                            listaQuestoesProm.reject(msgsService.getMsg('app', 3));
                        });
                    return listaQuestoesProm.promise;
                },
                saveAvaliacao: function (avaliacaoQuestoes){
                    var saveAvaliacaoProm = $q.defer();
                    db.dbActions('saveAvaliacao', { "avaliacaoQuestoes": avaliacaoQuestoes}, 'avaliacoes_adm')
                        .then(function (saveAvaliacaoResult) {
                            saveAvaliacaoProm.resolve(saveAvaliacaoResult);
                        }).catch(function (saveAvaliacaoError) {
                            console.log('saveAvaliacaoError', saveAvaliacaoError);
                            saveAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return saveAvaliacaoProm.promise;
                },
                atualizaAvaliacao: function (avaliacaoQuestoes){
                    var atualizaAvaliacaoProm = $q.defer();
                    db.dbActions('atualizaAvaliacao', avaliacaoQuestoes, 'avaliacoes_adm')
                        .then(function (atualizaAvaliacaoResult) {
                            atualizaAvaliacaoProm.resolve(atualizaAvaliacaoResult);
                        }).catch(function (atualizaAvaliacaoError) {
                            console.log('atualizaAvaliacaoError', atualizaAvaliacaoError);
                            atualizaAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return atualizaAvaliacaoProm.promise;
                },
                deleteAvaliacao: function (questao){
                    var deleteAvaliacaoProm = $q.defer();
                    db.dbActions('deleteAvaliacao', { "id": questao}, 'avaliacoes_adm')
                        .then(function (deleteAvaliacaoResult) {
                            if(!deleteAvaliacaoResult.removido){
                                deleteAvaliacaoProm.reject(msgsService.getMsg('app', 3));                                
                            }else{
                                deleteAvaliacaoProm.resolve(deleteAvaliacaoResult);
                            }
                        }).catch(function (deleteAvaliacaoError) {
                            console.log('deleteAvaliacaoError', deleteAvaliacaoError);
                            deleteAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return deleteAvaliacaoProm.promise;
                },
                deleteQuestaoAvaliacao: function (avaliacaoQuestao){
                    var deleteQuestaoAvaliacaoProm = $q.defer();
                    db.dbActions('deleteQuestaoAvaliacao', avaliacaoQuestao, 'avaliacoes_adm')
                        .then(function (deleteQuestaoAvaliacaoResult) {
                            if(!deleteQuestaoAvaliacaoResult.removido){
                                deleteQuestaoAvaliacaoProm.reject(msgsService.getMsg('app', 3));                                
                            }else{
                                deleteQuestaoAvaliacaoProm.resolve(deleteQuestaoAvaliacaoResult);
                            }
                        }).catch(function (deleteQuestaoAvaliacaoError) {
                            console.log('deleteQuestaoAvaliacaoError', deleteQuestaoAvaliacaoError);
                            deleteQuestaoAvaliacaoProm.reject(msgsService.getMsg('app', 3));
                        });
                    return deleteQuestaoAvaliacaoProm.promise;
                }
            }
        }
    )