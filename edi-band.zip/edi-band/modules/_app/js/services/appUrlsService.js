angular.module('bandEdi')
    .service('appUrls', [function() {
        return {
            getEnv: function() {
                var environments = {
                    "localhost": "dev",
                    "172":"dev",
                    "dev": "dev",
                    "web": "web-interno",
                    "web.bandeiranteslog":"web-externo"
                };
                var httpHost = window.location.hostname;
                var firstNameHost = httpHost.split('.');
                var enviroment = firstNameHost[0];
                if (firstNameHost[1] =='bandeiranteslog'){
                    enviroment = firstNameHost[0] +'.'+ firstNameHost[1];
                }
                return environments[enviroment];
            },
            getUrl: function(url) {
                var urlMaps = {
                    "dev": {
                        "app": "http://dev.new.band/ediband/services/v1/"
                    },
                    "web-interno": {
                        "app": "http://web.new.band/ediband/services/v1/"
                    },
                    "web-externo":{
                        "app": "http://web.bandeiranteslog.com.br/ediband/services/v1/"
                    }
                };
                return urlMaps[this.getEnv()][url];
            }
        }
    }])