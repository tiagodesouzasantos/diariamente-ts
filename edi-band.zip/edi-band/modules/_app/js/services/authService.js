angular.module('bandEdi')
    .service('auth', function (session, $q, $http, $state, appUrls, msgsService) {
        return {
            login: function(user) {
                var authProm = $q.defer();
                $http.post(appUrls.getUrl('app'), user)
                    .then(function(authResult) {
                        // console.log(authResult.data);
                        var auth = authResult.data;
                        if (auth.validPass && auth.userRH!=null){
                            authProm.resolve(auth);
                            session.setData('authData', JSON.stringify(auth));
                            session.setData('configs', JSON.stringify(auth.user.configs));
                        }else{
                            if (!auth.userExist && !auth.validPass && auth.userRH == null){
                                auth.msgError = msgsService.getMsg('usuario', 4);
                                authProm.reject(auth);
                            } else if (auth.userExist && !auth.validPass){                                
                                auth.msgError = msgsService.getMsg('usuario', 1);
                                authProm.reject(auth);
                            } else if (!auth.userExist && !auth.validPass && auth.userRH != null){
                                auth.msgError = msgsService.getMsg('usuario', 5);
                                authProm.resolve(auth);                            
                            } else if (auth.userExist && auth.validPass && auth.userRH == null) {
                                auth.msgError = msgsService.getMsg('usuario', 4);
                                authProm.reject(auth);
                            }else{
                                auth.msgError = msgsService.getMsg('usuario', 3);
                                authProm.reject(auth);
                            }
                        }
                    }).catch(function(authError) {
                        console.log('authError', authError);
                        authProm.reject(authResult);
                    });
                return authProm.promise;
            },
            logout: function() {
                session.clear();
                $state.go('initial');
            }
        }
    })