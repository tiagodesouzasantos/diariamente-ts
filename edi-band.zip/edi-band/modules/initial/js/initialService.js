angular.module('initial')
    .service('initialService',
        function($q, $http, db, msgsService, auth) {
            return {
                validaUsuario: function(usuario) {
                    var validaUsuarioProm = $q.defer();
                    if (usuario != null || usuario != undefined) {
                        validaUsuarioProm.resolve(usuario);
                    } else {
                        var confirmeJson = {
                            "title": "Problemas!",
                            "content": msgsService.getMsg('usuario', 1),
                            "buttonOk": "Ok"
                        };
                        validaUsuarioProm.reject(confirmeJson);
                    }
                    return validaUsuarioProm.promise;
                },
                login: function(usuario) {
                    var authProm = $q.defer();
                    usuario.acao = "auth";
                    usuario.modulo = "login";
                    auth.login(usuario).then(function(authResult) {
                        if (authResult.msgError){
                            authProm.reject(authResult);
                        }else{
                            authProm.resolve(authResult);
                        }
                    }).catch(function(authError) {
                        authProm.reject(authError);
                    });

                    return authProm.promise;
                },
                saveNewUser:function(usuario){
                    var saveNewUserProm = $q.defer();
                    db.dbActions('newUser', usuario, 'login')
                    .then(function (saveResult) {
                        console.log('salvando usuario', saveResult);
                        if (saveResult.created){
                            saveNewUserProm.resolve(msgsService.getMsg('app', 1));
                        }else{
                            var msg;
                            if (saveResult.userExist){
                                msg = msgsService.getMsg('app', 2);
                            } else if (!saveResult.colab){
                                msg = msgsService.getMsg('app', 4);
                            }
                            saveNewUserProm.reject(msg);
                        }
                    }).catch(function (saveError) {
                        saveNewUserProm.reject(msgsService.getMsg('app', 3));
                    });
                    return saveNewUserProm.promise;
                },
                recoverPass:function(usuario){
                    var recoverPassProm = $q.defer();
                    db.dbActions('recoverPass', usuario, 'login')
                        .then(function (recoverResult) {                            
                            recoverPassProm.resolve(msgsService.getMsg('app', 11));
                        }).catch(function (recoverError) {
                            recoverPassProm.reject(msgsService.getMsg('app', 3));
                        });
                    return recoverPassProm.promise;
                }
            }
        }
    )