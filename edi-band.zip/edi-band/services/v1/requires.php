<?php
require_once "modules/login/LoginBO.php";
require_once "modules/edi/EdiBO.php";
require_once "modules/vetorh/VetorhBO.php";
require_once "modules/avaliacoes-reacao/AvaliacaoReacaoBO.php";
require_once "modules/avaliacoes/AvaliacaoBO.php";
require_once "DBO/Conexao.php";
?>