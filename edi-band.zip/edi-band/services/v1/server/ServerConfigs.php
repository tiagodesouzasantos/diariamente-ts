<?php
include_once __DIR__.'/../secure/Environment.php';

class ServerConfigs{

    public static function getDbCon(){
        
        $serverExploded = explode('.',$_SERVER['HTTP_HOST']);
        $server = $serverExploded[0];
        $connections = array(
                            "dev"=>array(
                                'treinamentos'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('DEV_TREINA_DB_HOST').';Database='.Environment::getEnv('DEV_TREINA_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('DEV_TREINA_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('DEV_TREINA_DB_PASSWORD')
                                ),
                                'usuariosband'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('DEV_USUARIOS_BAND_DB_HOST').';Database='.Environment::getEnv('DEV_USUARIOS_BAND_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('DEV_USUARIOS_BAND_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('DEV_USUARIOS_BAND_DB_PASSWORD')
                                ),
                                'vetorh'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('PROD_VETORH_DB_HOST').';Database='.Environment::getEnv('PROD_VETORH_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('PROD_VETORH_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('PROD_VETORH_DB_PASSWORD')                                                                                                            
                                ),  
                                'ediband'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('DEV_EDI_BAND_DB_HOST').';Database='.Environment::getEnv('DEV_EDI_BAND_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('DEV_EDI_BAND_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('DEV_EDI_BAND_DB_PASSWORD')                                                                                                            
                                ),  
                            ),
                            "web"=>array(
                                'treinamentos'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('PROD_TREINA_DB_HOST').';Database='.Environment::getEnv('PROD_TREINA_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('PROD_TREINA_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('PROD_TREINA_DB_PASSWORD')
                                ),    
                                'vetorh'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('PROD_VETORH_DB_HOST').';Database='.Environment::getEnv('PROD_VETORH_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('PROD_VETORH_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('PROD_VETORH_DB_PASSWORD')                                                                                                            
                                ),  
                                'ediband'=>array(
                                    'dns'=>Environment::getEnv('DB_CONNECTION').':Server='.Environment::getEnv('DEV_EDI_BAND_DB_HOST').';Database='.Environment::getEnv('DEV_EDI_BAND_DB_DATABASE'),
                                    'usernameDB'=>Environment::getEnv('DEV_EDI_BAND_DB_USERNAME'),
                                    'passDB'=>Environment::getEnv('DEV_EDI_BAND_DB_PASSWORD')                                                                                                            
                                ), 
                            )
                        );                     
        return $connections[$server];
    }
}
?>